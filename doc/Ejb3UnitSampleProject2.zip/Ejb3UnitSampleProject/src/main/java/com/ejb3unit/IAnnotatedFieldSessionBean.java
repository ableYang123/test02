package com.ejb3unit;

import java.io.Serializable;

import javax.ejb.Remote;
import javax.persistence.EntityManager;
import javax.sql.DataSource;

/**
 * Local Interface.
 * 
 * @author Daniel Wiese
 * @since 08.11.2005
 */
@Remote
public interface IAnnotatedFieldSessionBean extends Serializable {

	/**
	 * Returns the ds.
	 * 
	 * @return Returns the ds.
	 */
	DataSource getDs();

	/**
	 * Returns the em.
	 * 
	 * @return Returns the em.
	 */
	EntityManager getEm();

	/**
	 * rturns a reference to a other sb.
	 * 
	 * @return reference to a other sb.
	 */
	IMySessionBean getSessionBean();

}
