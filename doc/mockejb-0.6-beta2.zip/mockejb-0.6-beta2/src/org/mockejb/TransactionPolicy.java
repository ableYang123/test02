package org.mockejb;

import java.io.Serializable;

/**
 * Enumeration of possible values of the transaction attribute (transaction 
 * policy) as per EJB spec.
 * <br>Used for setting the policy by calling <code>MockEjbObject.setTransactionPolicy()</code>
 * 
 * @author Alexander Ananiev
 */
public class TransactionPolicy implements Serializable {

    
    private final String name;
    
    private TransactionPolicy( String name){
        this.name=name;    
    }
    
    public String toString()  { 
        return this.name; 
    }
    
    public static final TransactionPolicy SUPPORTS = new TransactionPolicy("Supports");

    public static final TransactionPolicy REQUIRED = new TransactionPolicy("Required");

    public static final TransactionPolicy REQUIRED_NEW = new TransactionPolicy("RequiredNew");

    public static final TransactionPolicy NOT_SUPPORTED = new TransactionPolicy("NotSupported");

    public static final TransactionPolicy NEVER = new TransactionPolicy("Never");

    public static final TransactionPolicy MANDATORY = new TransactionPolicy("Mandatory");

}
