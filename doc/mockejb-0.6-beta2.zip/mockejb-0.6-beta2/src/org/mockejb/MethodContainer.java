package org.mockejb;

import java.lang.reflect.*;
import java.util.*;


/**
 * @author Alexander Ananiev
 */
class MethodContainer {
    private Class claz;
    
    Map methods = new HashMap();
    
    MethodContainer( final Class claz ){
        this.claz = claz;
    }
    
    
    void add( String name, Class[] argTypes){
        try{
        
            //Class [] noArg = {};
            methods.put(name,  claz.getMethod(name, argTypes) );
        }
        // to be able to use this method from the static initializer we must not throw Exception
        catch ( NoSuchMethodException noMethodEx ){
            throw new RuntimeException( "Fatal error: standard method is not found: "+noMethodEx.getMessage());    
        }
            
    }
    
    void add( String name ) {
        Class [] noArg = {};
        add( name, noArg);
    }

    // TODO: currently argTypes is ignored
    Method find( String name, Class[] argTypes) {
        return (Method) methods.get(name);
    }

    Method find( Method method ) {
        return find( method.getName(), method.getParameterTypes() );
    }


}
