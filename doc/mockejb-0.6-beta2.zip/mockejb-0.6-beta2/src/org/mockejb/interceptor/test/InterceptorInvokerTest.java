package org.mockejb.interceptor.test;

import java.lang.reflect.*;
import org.mockejb.interceptor.*;

import junit.framework.TestCase;

/**
 * 
 * @author Alexander Ananiev
 */
public class InterceptorInvokerTest extends TestCase {

    static final String TEST_CONTEXT = "testContext";

    private AspectSystem aspectSystem = AspectSystemFactory.getAspectSystem(); 
    
    private Object target;
    private Method ifaceMethod;
    private Method targetMethod;
        
    private InterceptorInvoker invoker;
    
	protected void setUp() throws Exception {

        target = new TestImpl();
        ifaceMethod = TestIface.class.getMethod( "echo", new Class[] { String.class } );
        targetMethod = TestImpl.class.getMethod( "echo", new Class[] { String.class } );
        
        invoker = new InterceptorInvoker();
	}
    
    public void testInvoke() throws Throwable {
        
        
        InterceptorInvoker invoker = new InterceptorInvoker();
        Object retVal = invoker.invoke( null, ifaceMethod, target, targetMethod, 
                new Object[] { "test" } );
        assertEquals("test", retVal );
        
        TestInterceptor interceptor = new TestInterceptor();

        aspectSystem.getAspectList().clear();

        aspectSystem.add( new ClassPointcut( TestIface.class ), 
            interceptor );
        retVal = invoker.invoke( null, ifaceMethod, target, targetMethod, new Object[] { "test" } );
        assertEquals("test", retVal );
        assertTrue( interceptor.wasInvoked() );
        
        // test target object pointcut
        aspectSystem.getAspectList().clear();
        interceptor = new TestInterceptor();
        aspectSystem.add( new ClassPointcut( TestImpl.class ), 
            interceptor );
        retVal = invoker.invoke( null, ifaceMethod, target, targetMethod, new Object[] { "test" } );
        assertEquals("test", retVal );
        assertTrue( interceptor.wasInvoked() );
        
    }
    
    public void testContext() throws Throwable {

     
        invoker.setContext(TEST_CONTEXT, "test");

        aspectSystem.getAspectList().clear();
        TestInterceptor interceptor = new TestInterceptor();
        aspectSystem.add( new ClassPointcut( TestIface.class ), 
            interceptor );

        Object retVal = invoker.invoke( null, ifaceMethod, target, targetMethod, new Object[] { "test" } );
        
        assertEquals("test", interceptor.getContext());        
                
    }
    
    
   

}
