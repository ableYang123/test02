package org.mockejb.interceptor.test;

import junit.framework.TestCase;
import org.mockejb.interceptor.*;
/**
 * 
 * @author Alexander Ananiev
 */
public class InterceptableProxyTest extends TestCase {
    
    public void testInterfaceProxy() throws Exception{
        
        TestIface proxy = (TestIface) InterceptableProxy.create( TestIface.class, new TestImpl() );
        
        assertEquals( "test", proxy.echo("test") );
    }
    
    public void testClassProxy() throws Exception{
        
        InterceptableTestClass proxy = (InterceptableTestClass) 
            InterceptableProxy.create( InterceptableTestClass.class, new TestImpl() );
        
        assertEquals( "test", proxy.echo("test") );
        
        // Intercept the calls to the class itself 
        proxy = (InterceptableTestClass) 
        InterceptableProxy.create( InterceptableTestClass.class, new InterceptableTestClass() );
    
        assertEquals( "test", proxy.echo("test") );
        
    }
    
}
