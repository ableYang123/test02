package org.mockejb.interceptor.test;


public interface TestIface {
    
    String echo( String s );
    
    void test();
    
}