package org.mockejb.interceptor.test;

class InterceptableTestClass {

    public String echo( String s ){
        return s;
    }
    
    /**
     * The most simple method there is
     */
    public void test(){
        
    }

}
