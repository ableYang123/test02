package org.mockejb.interceptor.test;


import org.mockejb.interceptor.Interceptor;
import org.mockejb.interceptor.InvocationContext;


class TestInterceptor implements Interceptor {
    static final String TEST_CONTEXT = "testContext";
    
    private boolean wasInvoked = false;
    private int callIndexBefore = 0;
    private int callIndexAfter = 0;

    private Exception exception;
    private Object context; 
    
    public void intercept( InvocationContext invocationContext)  throws Exception {
            
        wasInvoked= true;
        callIndexBefore = invocationContext.getInterceptorIterator().previousIndex();
            
        context = invocationContext.getOptionalPropertyValue( TEST_CONTEXT );

        System.out.println( "Was invoked: "+ callIndexBefore);        
        
        if ( exception != null )
            throw exception;
                    
        invocationContext.proceed();

        callIndexAfter = invocationContext.getInterceptorIterator().previousIndex();
            
    }
    
    boolean wasInvoked(){
        boolean tmpWasInvoked = wasInvoked;
        wasInvoked=false;
        return tmpWasInvoked;
    }
    
    int getCallIndexBefore(){
        return callIndexBefore;
    }
    
    int getCallIndexAfter(){
        return callIndexAfter;
    }
    
    void setThrowException( Exception exception ){
        this.exception=exception;
    }
    
    Object getContext(){
        return context;
    }
    
}