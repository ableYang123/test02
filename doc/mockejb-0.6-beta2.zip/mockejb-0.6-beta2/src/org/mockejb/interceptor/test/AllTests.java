package org.mockejb.interceptor.test;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * 
 * @author Alexander Ananiev
 */
public class AllTests {

    public static Test suite() {
        TestSuite suite =
            new TestSuite("Test for org.mockejb.interceptor.test");
        //$JUnit-BEGIN$
        suite.addTestSuite(InterceptorInvokerTest.class);
        suite.addTestSuite(InterceptableProxyTest.class);
        suite.addTestSuite(InvocationContextTest.class);
        suite.addTestSuite(PointcutTest.class);
        //$JUnit-END$
        return suite;
    }
}
