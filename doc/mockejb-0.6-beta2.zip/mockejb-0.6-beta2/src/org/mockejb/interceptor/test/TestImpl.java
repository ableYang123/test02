package org.mockejb.interceptor.test;

class TestImpl implements TestIface {

    /**
     * Implementation of our interface so we can call this method using reflection. 
     */
    public String echo( String s ){
        return s;
    }
    
    /**
     * The most simple method there is
     */
    public void test(){
        
    }

}
