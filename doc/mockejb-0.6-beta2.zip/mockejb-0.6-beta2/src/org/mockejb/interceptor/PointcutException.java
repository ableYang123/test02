package org.mockejb.interceptor;


/**
 * Signifies exception in the pointcut, for example
 * errors in the provided regexp patterns. 
 * Support exception chaining for 1.3 users just in case.
 * 
 * @author  Alexander Ananiev
 */
public class PointcutException extends AspectException {
    
    private Throwable cause;
    
    /** 
     * Creates a new instance of <code>PointcutException</code>.
     * Appends the error stack of the cause to the message to remain 1.3 compliant.
     * @param message error message
     * @param cause cause of the exception
     */
    public PointcutException( String message, Throwable cause ) {
        super( message, cause );
    }

    public PointcutException( String message ){
        super( message );
    }

    
}
