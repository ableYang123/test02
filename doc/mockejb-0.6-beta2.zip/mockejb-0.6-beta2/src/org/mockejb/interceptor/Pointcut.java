package org.mockejb.interceptor;

import java.lang.reflect.Method;

/**
 * Represents the AOP "pointcut" abstraction.
 * Note that AspectSystem matches pointcuts only 
 * against intercepted methods. For example, "find" method of an
 * Entity interface triggers the call to the ejbFind method of the
 * entity bean implementation class. Using pointcuts, you can only
 * match the "find" method and the business interface but not the target
 * method/object being called in response to the interface call. 
 * 
 * @author Alexander Ananiev
 */
public interface Pointcut {
    
    /**
     * Tests if the provided jointpoint represented by the intercepted object (object being called)
     * and the method matches this pointcut. In other words, tests if the interceptor
     * associated with this pointcut needs to be applied to the provided jointpoint. 
     * 
     * @param method method being invoked
     * @return true if the target object or method match the condition specified in
     * this pointcut
     */
    boolean matchesJointpoint( Method method );

}
