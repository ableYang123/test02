package org.mockejb.interceptor;


/**
 * Aspect is the combination of an interceptor and pointcut.
 * You want to implement Aspect interface when your interceptor 
 * can only handle the specific method/classes (jointpoints) and can't be used with any
 * other pointcut. 
 * In case if Interceptor is truly universal (see, for example, 
 * {@link InvocationRecorder}) you can use the appropriate "add" method
 * of the {@link AspectSystem} to combine the interceptor with any pointcut dynamically.
 * 
 * @author Alexander Ananiev
 */
public interface Aspect  extends Interceptor {

    Pointcut getPointcut();
}
