package org.mockejb.interceptor;

import java.lang.reflect.Method;

/**
 * Tests if the string representation of the given method
 * matches the regexp. This pointcut uses "toString"
 * representation of the method and then checks 
 * if it contains the regexp given to the constructor.
 * Example of string representation:
 * "public boolean java.lang.Object.equals(java.lang.Object)"
 *  
 * @author Alexander Ananiev
 */
public class MethodPatternPointcut implements Pointcut {
    
    private RegexpWrapper regexpWrapper;
    
    /**
     * Creates a new instance of MethodPatternPoincut
     * @param regexpPattern regexp pattern that will be matched against the 
     * string representation of the method
     */
    public MethodPatternPointcut( String regexpPattern ) {
        regexpWrapper = new RegexpWrapper( regexpPattern ); 
    }

    
    /**
     * Tests if the string representation of the given method
     * matches the pattern.
     * 
     * @return true if the provided method should be intercepted
     */
    public boolean matchesJointpoint( Method method ) {

        return regexpWrapper.containedInString( method.toString() );
        
    }
    
    /**
     * Returns true if the given object is of the same type and 
     * it has the same pattern.
     */
    public boolean equals( Object obj ){
        
        if ( ! (obj instanceof MethodPatternPointcut) )
            return false;
        
        MethodPatternPointcut methodPatternPointcut = (MethodPatternPointcut ) obj;
        
        return ( regexpWrapper.equals( methodPatternPointcut.regexpWrapper ));
    }

    public int hashCode() {
        return  regexpWrapper.hashCode(); 
    }    
    
    
}
