package org.mockejb.interceptor;

import java.io.PrintWriter;
import java.io.StringWriter;


/**
 * General-level exception used for various aspect/interceptor system exceptions. 
 * Support exception chaining for 1.3 users just in case.
 * 
 * @author  Alexander Ananiev
 */
public class AspectException extends RuntimeException {
    
    private Throwable cause;
    
    /** 
     * Creates a new instance of <code>AspectException</code>.
     * Appends the error stack of the cause to the message to remain 1.3 compliant.
     * @param message error message
     * @param cause cause of the exception
     */
    public AspectException( String message, Throwable cause ) {
        super( message +"\nCause:\n" + stackToString( cause ));
        this.cause = cause;
    }
    
    public AspectException( Throwable cause ) {
        this( "", cause);
    }

    public AspectException( String message ){
        super( message );
    }
    

    /**
     * Returns the cause of this throwable or null if the cause is nonexistent 
     * or unknown. 
     * 
     * @return the cause of this throwable or null if the cause is 
     * nonexistent or unknown
     * 
     */ 
    public Throwable getCause() {
        return cause;
    }

    private static String stackToString( Throwable e ) {
        StringWriter stringWriter = new StringWriter(); 
        e.printStackTrace( new PrintWriter( stringWriter ) );
        
        return stringWriter.toString();
    }

    
}
