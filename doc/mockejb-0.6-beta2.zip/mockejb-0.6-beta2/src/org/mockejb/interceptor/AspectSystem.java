package org.mockejb.interceptor;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Keeps the global list of aspects.
 * Identifies the relevant aspects and interceptors
 * for the given jointpoint.
 * 
 * @author Alexander Ananiev
 */
public interface AspectSystem {

    /**
     * Adds the given aspect to the end of the global list of aspects.
     * 
     * @param aspect aspect to add
     */
    void add( Aspect aspect );
    
    /**
     * Inserts the given aspect in the beginning of the list of aspects.
     * 
     * If you want an interceptor for a given pointcut to be called 
     * before other interceptors for the same pointcut, you can use this method.
     *  
     * @param aspect aspect to add
     */
    void addFirst( Aspect aspect );
    
    
    /**
     * Creates the new aspect and adds it to the end of the list of aspects.
     * 
     * @param pointcut pointcut of the aspect
     * @param interceptor interceptor of the aspect
     */
    void add( Pointcut pointcut, Interceptor interceptor );

    /**
     * Creates the new aspect from the given pointcut and the interceptor 
     * and inserts it in the beginning of the list of aspects.
     *
     * If you want an interceptor for a given pointcut to be called 
     * before other interceptors for the same pointcut, you can use this method.
     *  
     * @param pointcut pointcut of the aspect
     * @param interceptor interceptor of the aspect
     */
    void addFirst( Pointcut pointcut, Interceptor interceptor );
    
    
    /**
     * Returns the list of aspects to the client. Clients can 
     * manipulate the list. 
     * 
     * @return the list of aspects
     */
    List getAspectList();
    
    
    /**
     * Identifiesaspects whose pointcut matches the given source method or
     * target method. Returns the list of the interceptors for the matching 
     * pointcuts. 
     * 
     * @param proxyMethod method invoked by the client on the proxy (interface method)
     * @param targetMethod target method which will be called as the result of the proxy method
     * 
     * @return list of the interceptors for the matching pointcuts
     */
    List findInterceptors( Method proxyMethod, Method targetMethod );
    
    /**
     * Clears the aspect list
     */
    void clear();

}
