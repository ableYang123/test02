package org.mockejb.interceptor;

import java.lang.reflect.Method;

/**
 * Tests if the class name of the provided method matches the regexp.
 *  
 * @author Alexander Ananiev
 */
public class ClassPatternPointcut implements Pointcut {

    private RegexpWrapper regexpWrapper;    
    
    /**
     * Creates a new instance of ClassPatternPoincut
     * @param regexpPattern regexp pattern that will be matched against the fully qualified class name
     * 
     */
    public ClassPatternPointcut( String regexpPattern ){
        
        regexpWrapper = new RegexpWrapper( regexpPattern ); 
        
    }

    
	/**
     * Tests if the fully qualified class name of the given method
     * 
     * @return true if the provided method should be intercepted
	 */
	public boolean matchesJointpoint( Method method ) {

        return regexpWrapper.containedInString( method.toString() );       
        
	}
    
    /**
     * Returns true if the given object is of the same type and 
     * it has the same pattern.
     */
    public boolean equals( Object obj ){
        if ( ! (obj instanceof ClassPatternPointcut) )
            return false;
        
        ClassPatternPointcut classPatternPointcut = (ClassPatternPointcut ) obj;
        
        return ( regexpWrapper.equals( classPatternPointcut.regexpWrapper ));
    }

    public int hashCode() { 
        return  regexpWrapper.hashCode();  
    }    
    
    
}
