package org.mockejb.interceptor;

/**
 * This class provides a simple way to create an aspect
 * from the existing interceptor and pointcut. Used internally by the AspectSystem. 
 *  
 * @author Alexander Ananiev
 */
class InterceptorContainerAspect implements Aspect {

    private Pointcut pointcut;
    private Interceptor interceptor;

    public InterceptorContainerAspect( Pointcut pointcut, Interceptor interceptor ) {
    	
        if ( pointcut==null )
            throw new IllegalArgumentException("Interceptor can't be null");
        
        if ( interceptor==null )
            throw new IllegalArgumentException("Pointcut can't be null");
        
        this.pointcut = pointcut;
        this.interceptor = interceptor;
    }
    
    public Pointcut getPointcut() {
    	return pointcut;
    }
    
    public void intercept( InvocationContext invocationContext )  throws Exception {
    	interceptor.intercept( invocationContext );
    }
    
    
    public Interceptor getInterceptor() {
        return interceptor;
    }
    
    /**
     * Returns true if the given object is of type Aspect
     * and its pointcut and interceptor equal to the ones of this object  
     */
    public boolean equals( Object obj ){

        if ( ! (obj instanceof InterceptorContainerAspect) )
            return false;
        
        InterceptorContainerAspect aspect = (InterceptorContainerAspect ) obj;
        
        return ( pointcut.equals( aspect.pointcut ) && interceptor.equals( aspect.interceptor) ); 
    }
   
    public int hashCode() { 
    	
        int result = 17;
        result = 37*result+pointcut.hashCode();
        result = 37*result+interceptor.hashCode();
        
        return result; 
        
    }    
    
}
