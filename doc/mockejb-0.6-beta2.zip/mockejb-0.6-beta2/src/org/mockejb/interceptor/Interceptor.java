package org.mockejb.interceptor;


/**
 * Interceptors intercept calls to an object to perform some actions, such as logging, 
 * transaction management and so on. 
 * Interceptor can perform actions before the call, then it must call the 
 * {@link InvocationContext#proceed proceed} method 
 * and after that it can perform post-call actions if needed. 
 * 
 * @author Alexander Ananiev
 */
public interface Interceptor {

    /**
     * Performs pre and post invocation actions for the target object call.
     * @param invocationContext provides the info about this call. Also calls interceptors in 
     * turn according to their order in the chain. invocationContext provides access to the return value
     * and thrown exceptions of this call.
     */
    void intercept( InvocationContext invocationContext )  throws Exception;

}
