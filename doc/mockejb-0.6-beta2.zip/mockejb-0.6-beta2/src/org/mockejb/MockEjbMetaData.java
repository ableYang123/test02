package org.mockejb;

import java.io.Serializable;

import javax.ejb.*;

/**
 * Provides the implementation of <code>javax.ejb.EJBMetaData</code>
 * 
 * @author Alexander Ananiev
 */
public class MockEjbMetaData implements EJBMetaData, Serializable {
    
    private BasicEjbDescriptor descriptor;
    private Object homeProxy;
    
    MockEjbMetaData( final BasicEjbDescriptor descriptor ) {
        this.descriptor = descriptor;
    }

    
    void setHomeProxy( final Object homeProxy ) {
        this.homeProxy = homeProxy;
    }

    /**
     * @see javax.ejb.EJBMetaData#getEJBHome()
     */
    public EJBHome getEJBHome() {
        return (EJBHome) homeProxy;
    }

    /**
     * @see javax.ejb.EJBMetaData#getHomeInterfaceClass()
     */
    public Class getHomeInterfaceClass() {
        return descriptor.getHomeClass();
    }

    /**
     * @see javax.ejb.EJBMetaData#getRemoteInterfaceClass()
     */
    public Class getRemoteInterfaceClass() {
        return descriptor.getIfaceClass();
    }

    /**
     * Currently this method always returns <code>null</code>
     * @return <code>null</code>
     * @see javax.ejb.EJBMetaData#getPrimaryKeyClass()
     */
    public Class getPrimaryKeyClass() {
        return null;
    }

    /**
     * Checks if this bean is ths session bean.
     * @return <code>true</code> if the bean this metadata associated with is a session bean
     * @see javax.ejb.EJBMetaData#isSession()
     */
    public boolean isSession() {
        return (descriptor instanceof SessionBeanDescriptor);
    }

    /**
     * @see javax.ejb.EJBMetaData#isStatelessSession()
     */
    public boolean isStatelessSession() {
        return ( descriptor instanceof SessionBeanDescriptor && !((SessionBeanDescriptor) descriptor).isStateful() );
    }

}
