package org.mockejb;

/**
 * Provides in-memory entity database implementation suitable for 
 * setting up test mock data.
 * Entities can be searched only by the primary key.
 * Users should populate EntityDatabase with the mock entities for their test. 
 * MockEJB searches EntityDatabase: 
 * 1) During the call to CMP findByPrimaryKey.
 * 2) After a BMP finder returns a PK or collection of PKs.
 * MockEJB automatically add an entity to this "database" if
 * its ejbCreate method returns a PK. 
 * 
 * Note that you can use aspects/interceptors to intercept all calls to this
 * class.  
 *  
 * @author Alexander Ananiev
 */
public interface EntityDatabase {

    void add( Class homeIfaceClass, Object pk, Object entity );
    
    Object find( Class homeIfaceClass, Object pk );
    
    void clear();
}