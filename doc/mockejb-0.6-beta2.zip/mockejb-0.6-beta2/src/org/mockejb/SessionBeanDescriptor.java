package org.mockejb;


/**
 * Provides Session bean-specific information required by MockContainer 
 * to deploy session EJB.
 * The only piece if session-bean specific data is <code>isStateful</code> flag. 
 *  
 * @author Alexander Ananiev
 */
public class SessionBeanDescriptor extends BasicEjbDescriptor  {
    
    private boolean isStateful = false;
    
    /**
     * Creates a new instance of the descriptor.
     * @param jndiName  jndiName to bind Home to. Note that MockEjb does not support
     * bean-scoped context, so this name must be unique.
     * @param homeClass class of the home interface 
     * @param ifaceClass class of the business interface, remote or local
     * @param beanClass class of the implementation class 
     */     
    // TODO: Deprecate?
    public SessionBeanDescriptor( String jndiName, Class homeClass, Class ifaceClass, 
        Class beanClass ) {

        super( jndiName, homeClass, ifaceClass, beanClass );
    }

    /**
     * Creates a new instance of the descriptor.
     * @param jndiName  jndiName to bind Home to. Note that MockEjb does not support
     * bean-scoped context, so this name must be unique.
     * @param homeClass class of the home interface 
     * @param ifaceClass class of the business interface, remote or local
     * @param bean instance of a bean implementation class. 
     */     
    public SessionBeanDescriptor( String jndiName, Class homeClass, Class ifaceClass, 
            Object bean ) {
        super( jndiName, homeClass, ifaceClass, bean );
    }
    
    
    public void setStateful( boolean isStateful ){
        this.isStateful = isStateful;
    }


    /**
     * Returns true if this bean is the stateful bean. Note that MockEJB treats
     * stateless and stateful session beans exactly the same way since there is no
     * pooling involved. 
     * This setting is only used by EJBMetaData in case if the client calls
     * isStateless method. 
     * @return true if the bean is the stateful bean.
     */
    public boolean isStateful(){
        return isStateful;
    }

}
