package org.mockejb;

import java.io.Serializable;


/**
 * Provides the information that MockEJB needs to "deploy" this EJB. This 
 * includes classes of EJB Home, business interface and implementation.
 * {@link MockContainer} uses this data to create dynamic proxies acting as Home
 * and EJBObject.
 * This is the base class for concrete MDB, Session and Entity Descriptor implementations.
 *  
 * @author Alexander Ananiev
 */
public abstract class BasicEjbDescriptor implements Serializable {
    
    private Class homeClass;
    private Class ifaceClass;
    private Class beanClass;
    private Object bean;
    private String jndiName;
    
    /**
     * Creates a new instance of the descriptor.
     * @param jndiName  jndiName to bind Home to. Note that MockEjb does not support
     * bean-scoped context, so this name must be unique.
     * @param homeClass class of the home interface 
     * @param ifaceClass class of the business interface, remote or local
     * @param beanClass class of the implementation class 
     */     
    // TODO: Deprecate?
    public BasicEjbDescriptor( String jndiName, Class homeClass, Class ifaceClass, 
        Class beanClass ) {
        
        this.jndiName = jndiName;
        this.homeClass = homeClass;    
        this.ifaceClass = ifaceClass;    
        this.beanClass = beanClass;
    }

    /**
     * Creates a new instance of the descriptor.
     * @param jndiName  jndiName to bind Home to. Note that MockEjb does not support
     * bean-scoped context, so this name must be unique.
     * @param homeClass class of the home interface 
     * @param ifaceClass class of the business interface, remote or local
     * @param bean instance of a bean implementation class. 
     */     
    public BasicEjbDescriptor( String jndiName, Class homeClass, Class ifaceClass, 
            Object bean ) {
        
        this.jndiName = jndiName;
        this.homeClass = homeClass;    
        this.ifaceClass = ifaceClass;    
        this.bean = bean;
    }
    
    
    public String getJndiName(){
        return jndiName;
    }
    
    public Class getHomeClass(){
        return homeClass;
    }
    
    public Class getBeanClass(){
        return beanClass;
    }

    public Object getBean(){
        return bean;
    }
    
    
    public Class getIfaceClass(){
        return ifaceClass;
    }
    
}
