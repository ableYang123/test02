package org.mockejb;

import javax.jms.MessageListener;

/**
 * Fake home interface to use by the MockContainer
 * so we can re-use the same Home class (SessionMDBHome
 * 
 */
interface MDBHomeIface {
    MessageListener create();
    
}
