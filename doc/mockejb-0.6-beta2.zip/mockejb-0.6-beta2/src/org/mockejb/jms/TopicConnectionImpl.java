package org.mockejb.jms;

import javax.jms.*;
import org.mockejb.MethodNotImplementedException;

/**
 * <code>TopicConnection</code> implementation
 * @author Dimitar Gospodinov
 */
class TopicConnectionImpl extends MockConnection implements TopicConnection {

    /**
     * Creates new topic connection for the specified client Id. 
     * @param clientId
     */
    TopicConnectionImpl(int clientId) {
        super("TopicClient:" + clientId);
    }

    /**
     * Creates new topic session.
     * @see javax.jms.TopicConnection#createTopicSession(boolean, int)
     */
    public TopicSession createTopicSession(
        boolean transacted,
        int acknowledgeMode)
        throws JMSException {

        return (TopicSession)createSession(transacted, acknowledgeMode);
    }

    /**
     * Not implemented.
     * @see javax.jms.TopicConnection#createConnectionConsumer(
     *           javax.jms.Topic, java.lang.String,
     *           javax.jms.ServerSessionPool,int)
     */
    public ConnectionConsumer createConnectionConsumer(
        Topic topic,
        String messageSelector,
        ServerSessionPool sessionPool,
        int maxMessages)
        throws JMSException {

        throw new MethodNotImplementedException(
            "createConnectionConsumer",
            "TopicConnectionImpl");
    }

    /**
     * Not implemented.
     */
    public ConnectionConsumer createDurableConnectionConsumer(
        Topic topic,
        String subscriptionName,
        String messageSelector,
        ServerSessionPool sessionPool,
        int maxMessages)
        throws JMSException {

        throw new javax.jms.IllegalStateException(
            "Queue connection can not create durable connection consumer!");
    }

    //  Non-standard methods

     MockSession createMockSession(boolean transacted, int acknowledgeMode) {
         return new TopicSessionImpl(transacted, acknowledgeMode, this);
     }     
}
