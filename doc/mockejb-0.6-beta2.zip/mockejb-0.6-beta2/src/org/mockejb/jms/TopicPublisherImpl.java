package org.mockejb.jms;

import javax.jms.*;

/**
 * <code>TopicPublisher</code> implementation.
 * Supports only <code>MockDestination</code> destinations.
 * @author Dimitar Gospodinov
 */
class TopicPublisherImpl extends MockProducer implements TopicPublisher {

    /**
     * Creates new topic publisher for <code>topic</code>. 
     * @param topic
     */
    public TopicPublisherImpl(MockTopic topic) {
        super(topic);
    }

    /**
     * @see javax.jms.TopicPublisher#getTopic()
     */
    public Topic getTopic() throws JMSException {
        return (Topic) getDestination();
    }

    /**
     * @see javax.jms.TopicPublisher#publish(javax.jms.Message)
     */
    public void publish(Message msg) throws JMSException {
        send(msg);
    }

    /**
     * @see javax.jms.TopicPublisher#publish(javax.jms.Message, int, int, long)
     */
    public void publish(
        Message msg,
        int deliveryMode,
        int priority,
        long timeToLive)
        throws JMSException {

        send(msg, deliveryMode, priority, timeToLive);
    }

    /**
     * @see javax.jms.TopicPublisher#publish(javax.jms.Topic, javax.jms.Message)
     */
    public void publish(Topic topic, Message msg) throws JMSException {
        publish(topic, msg, getDeliveryMode(), getPriority(), 0);
    }

    /**
     * @see javax.jms.TopicPublisher#publish(javax.jms.Topic, javax.jms.Message, int, int, long)
     */
    public void publish(
        Topic topic,
        Message msg,
        int deliveryMode,
        int priority,
        long timeToLive)
        throws JMSException {

        checkDestination(true);
        if (topic instanceof MockTopic) {
            MockProducer.sendMessage(
                (MockTopic) topic,
                msg,
                deliveryMode,
                priority,
                timeToLive);
        }
        throw new InvalidDestinationException("Invalid topic specified!");
    }
}
