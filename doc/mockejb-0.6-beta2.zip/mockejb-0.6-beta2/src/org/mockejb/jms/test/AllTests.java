package org.mockejb.jms.test;

import junit.framework.*;

/**
 * @author dgospodinov
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * org.mockejb.jms
 */
public class AllTests {

    public static Test suite() {
        TestSuite suite = new TestSuite("MockEjb JMS tests");

        suite.addTest(new TestSuite(org.mockejb.jms.test.MessageImplTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.TextMessageImplTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.ObjectMessageImplTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.BytesMessageImplTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.MapMessageImplTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.StreamMessageImplTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.TopicTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.QueueTest.class));
        suite.addTest(new TestSuite(org.mockejb.jms.test.ConsumersTest.class));
                
        return suite;
    }
}
