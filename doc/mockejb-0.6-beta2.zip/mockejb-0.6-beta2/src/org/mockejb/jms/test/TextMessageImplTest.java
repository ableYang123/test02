package org.mockejb.jms.test;

import javax.jms.*;

import org.mockejb.jms.TextMessageImpl;

/**
 * Tests <code>TextMessageImpl</code>.
 * 
 * @author Dimitar Gospodinov
 */
public class TextMessageImplTest extends MessageTester {

    private TextMessage msg;

    public TextMessageImplTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        msg = new TextMessageImpl();
        message = msg;
        super.setUp();
    }

    protected void tearDown() throws Exception {
        msg = null;
    }

    public void testTextMessage() throws JMSException {
        
        assertNull(msg.getText());
        msg.setText("Text");
        assertEquals(msg.getText(), "Text");
        msg.setText("Text1");
        assertEquals(msg.getText(), "Text1");
        msg.clearBody();
        assertNull(msg.getText());
        msg.setText("Text2");

        TextMessage msg1 = new TextMessageImpl(msg);
        assertEquals(msg1.getText(), "Text2");

        checkMessageAttributes(msg1);
        checkMessageAttributes();

        msg = new TextMessageImpl("Text3");
        assertEquals(msg.getText(), "Text3");
    }
}
