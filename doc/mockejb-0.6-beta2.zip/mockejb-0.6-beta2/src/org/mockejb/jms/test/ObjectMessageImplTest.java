package org.mockejb.jms.test;

import java.io.Serializable;
import javax.jms.*;

import org.mockejb.jms.MessageUtility;
import org.mockejb.jms.ObjectMessageImpl;

/**
 * Tests <code>ObjectMessageImpl</code>
 * 
 * @author Dimitar Gospodinov
 */
public class ObjectMessageImplTest extends MessageTester {

    private ObjectMessage msg;

    public ObjectMessageImplTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        msg = new ObjectMessageImpl();
        message = msg;
        super.setUp();
    }

    protected void tearDown() throws Exception {
        msg = null;
    }

    public void testObjectMessage() throws JMSException {

        assertNull(msg.getObject());

        Object o = new Integer(12345);

        msg.setObject((Serializable) o);
        assertNotSame(msg.getObject(), o);
        assertEquals(msg.getObject(), o);

        ObjectMessage msg1 = new ObjectMessageImpl(msg);
        assertNotSame(msg.getObject(), msg1.getObject());
        assertEquals(msg.getObject(), msg1.getObject());

        assertTrue(MessageUtility.compare(msg, msg1));

        msg.clearBody();        
        assertNull(msg.getObject());
        assertFalse(MessageUtility.compare(msg, msg1));
        msg1.clearBody();
        assertTrue(MessageUtility.compare(msg, msg1));
        

        checkMessageAttributes(msg1);
        checkMessageAttributes();
        
        msg = new ObjectMessageImpl((Serializable) o);
        assertNotSame(msg.getObject(), o);
        assertEquals(msg.getObject(), o);
    }

}
