package org.mockejb.jms.test;

import javax.jms.*;

public  class TestListener implements MessageListener {

        public void onMessage(Message msg) {
            try {
                if (msg instanceof TextMessage) {
                    System.out.println("Received TextMessage: " + ((TextMessage)msg).getText());
                } else {
                    System.out.println("Received Message: " + msg);
                }
            } catch (JMSException ex) {
                throw new RuntimeException("JMSException thrown: " + ex.getMessage());
            }
        }
}
