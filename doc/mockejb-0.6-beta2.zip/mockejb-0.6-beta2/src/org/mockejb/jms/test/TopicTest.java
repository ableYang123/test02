package org.mockejb.jms.test;

import junit.framework.TestCase;
import javax.jms.*;

/**
 * Tests sending messages to a <code>Topic</code>.
 * 
 * @author Dimitar Gospodinov
 */
public class TopicTest extends TestCase {

    public TopicTest(String name) {
        super(name);
    }
    
    public void testTopic() throws JMSException {
        
    }

}
