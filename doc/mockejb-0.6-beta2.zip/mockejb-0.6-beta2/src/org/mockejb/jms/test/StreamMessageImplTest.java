package org.mockejb.jms.test;

import javax.jms.*;

import org.mockejb.jms.MessageUtility;
import org.mockejb.jms.StreamMessageImpl;

/**
 * Tests <code>StreamMessageImpl</code>.
 * 
 * @author Dimitar Gospodinov
 */
public class StreamMessageImplTest extends MessageTester {

    private StreamMessage msg;

    public StreamMessageImplTest(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        msg = new StreamMessageImpl();
        message = msg;
        super.setUp();
    }

    protected void tearDown() throws Exception {
        msg = null;
    }

    public void testMessageNotReadable() throws JMSException {

        try {
            msg.readBoolean();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readBytes(new byte[5]);
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readString();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.readObject();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        checkMessageAttributes();
    }

    public void testMessageNotWritable() throws JMSException {

        msg.reset();

        try {
            msg.writeBoolean(true);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeByte((byte) 1);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeBytes(new byte[5]);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeBytes(null);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeBytes(new byte[5], 0, 1);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeBytes(null, 0, 1);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeChar('a');
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeDouble(123.33);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeFloat((float) 22.22);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeInt(122);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeLong(11);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeShort((short) 88);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeObject(null);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        try {
            msg.writeString("string");
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        checkMessageAttributes();
    }

    private void checkTestStreamMessage(StreamMessage msg)
        throws JMSException {
        byte[] bytesData = new byte[4];
        assertTrue(msg.readBoolean());
        assertEquals(msg.readBytes(new byte[1]), -1);
        assertNull(msg.readObject());
        assertEquals(msg.readByte(), (byte) 255);

        assertEquals(msg.readBytes(bytesData), 4);
        assertEquals(bytesData[0], (byte) 1);
        assertEquals(bytesData[1], (byte) 2);
        assertEquals(bytesData[2], (byte) 3);
        assertEquals(bytesData[3], (byte) 4);
        assertEquals(msg.readBytes(bytesData), -1);
        assertEquals(msg.readBytes(bytesData), 1);
        assertEquals(bytesData[0], (byte) 2);
        assertEquals(msg.readBytes(bytesData), -1);

        assertEquals(msg.readChar(), 'a');
        assertEquals(msg.readDouble(), 1.77E307, 0.01E307);
        assertEquals(msg.readFloat(), (float) 44.9991, (float) 0.0001);
        assertEquals(msg.readInt(), 65536);
        assertEquals(msg.readLong(), 9999222233338888L);
        assertEquals(msg.readShort(), (short) 32000);
        assertEquals(msg.readString(), "String 1");
        assertEquals(msg.readString(), "String 2");

        /*
         * At this point all bytes from msg have been read. Any read must throw EOF
         * exception.
         */
        try {
            msg.readBoolean();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readObject();
            fail();
        } catch (MessageEOFException ex) {
        }
        try {
            msg.readString();
            fail();
        } catch (MessageEOFException ex) {
        }
    }

    public void testStreamMessage() throws Throwable {

        byte[] bytesData1 = { 1, 2, 3, 4 };

        // Write to BytesMessage and DataOutputStream and then compare

        msg.writeBoolean(true);
        msg.writeBytes(null);
        msg.writeObject(null);
        msg.writeByte((byte) 255);
        msg.writeBytes(bytesData1);
        msg.writeBytes(bytesData1, 1, 1);
        msg.writeChar('a');
        msg.writeDouble(1.77E307);
        msg.writeFloat((float) 44.9991);
        msg.writeInt(65536);
        msg.writeLong(9999222233338888L);
        msg.writeShort((short) 32000);
        msg.writeString("String 1");
        msg.writeString("String 2");

        int repetitions = 2;
        while (repetitions-- > 0) {
            msg.reset();
            checkTestStreamMessage(msg);
        }
        msg.reset();

        StreamMessage msg1 = new StreamMessageImpl(msg);
        msg1.reset();
        checkTestStreamMessage(msg1);

        checkMessageAttributes(msg1);
        checkMessageAttributes();
        
        assertTrue(MessageUtility.compare(msg, msg1));
    }

    public void testBoolean() throws JMSException {

        msg.writeBoolean(true);
        try {
            msg.readBoolean();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertTrue(msg.readBoolean());
        msg.reset();
        assertEquals(msg.readString(), "true");
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Boolean);
        assertTrue(((Boolean) o).booleanValue());

        try {
            msg.readBoolean();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }

        checkMessageAttributes();
    }

    public void testByte() throws JMSException {

        msg.writeByte((byte) 127);
        try {
            msg.readByte();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readByte(), (byte) 127);
        msg.reset();
        assertEquals(msg.readShort(), (short) 127);
        msg.reset();
        assertEquals(msg.readInt(), 127);
        msg.reset();
        assertEquals(msg.readLong(), 127L);
        msg.reset();
        assertEquals(msg.readString(), Byte.valueOf("127").toString());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Byte);
        assertEquals(((Byte) o).byteValue(), (byte) 127);

        try {
            msg.readByte();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }
        checkMessageAttributes();
    }

    public void testChar() throws JMSException {

        msg.writeChar('e');
        try {
            msg.readChar();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readChar(), 'e');
        msg.reset();
        assertEquals(msg.readString(), "e");
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Character);
        assertEquals(((Character) o).charValue(), 'e');

        try {
            msg.readChar();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }

        checkMessageAttributes();
    }

    public void testShort() throws JMSException {

        msg.writeShort((short) 29000);
        try {
            msg.readShort();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readShort(), (short) 29000);
        msg.reset();
        assertEquals(msg.readInt(), 29000);
        msg.reset();
        assertEquals(msg.readLong(), 29000L);
        msg.reset();
        assertEquals(msg.readString(), Short.valueOf("29000").toString());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Short);
        assertEquals(((Short) o).shortValue(), (short) 29000);

        try {
            msg.readShort();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }

        checkMessageAttributes();
    }

    public void testInt() throws JMSException {

        msg.writeInt(120000);
        try {
            msg.readInt();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readInt(), 120000);
        msg.reset();
        assertEquals(msg.readLong(), 120000L);
        msg.reset();
        assertEquals(msg.readString(), Integer.valueOf("120000").toString());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Integer);
        assertEquals(((Integer) o).intValue(), 120000);

        try {
            msg.readInt();
            fail();
        } catch (MessageEOFException ex) {
        }
        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }

        checkMessageAttributes();
    }

    public void testLong() throws JMSException {

        msg.writeLong(222200002222L);
        try {
            msg.readLong();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readLong(), 222200002222L);
        msg.reset();
        assertEquals(msg.readString(), Long.valueOf("222200002222").toString());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Long);
        assertEquals(((Long) o).longValue(), 222200002222L);

        try {
            msg.readLong();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }

        checkMessageAttributes();
    }

    public void testFloat() throws JMSException {

        msg.writeFloat((float) 1678.1234);
        try {
            msg.readFloat();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readFloat(), (float) 1678.1234, (float) 0.0001);
        msg.reset();
        assertEquals(msg.readDouble(), 1678.1234, 0.0001);
        msg.reset();
        assertEquals(msg.readString(), Float.valueOf("1678.1234").toString());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Float);
        assertEquals(
            ((Float) o).floatValue(),
            (float) 1678.1234,
            (float) 0.0001);

        try {
            msg.readFloat();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }
        checkMessageAttributes();
    }

    public void testDouble() throws JMSException {

        msg.writeDouble(9.989667788E304);
        try {
            msg.readDouble();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readDouble(), 9.989667788E304, 0.000000001E304);
        msg.reset();
        assertEquals(
            msg.readString(),
            Double.valueOf("9.989667788E304").toString());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof Double);
        assertEquals(
            ((Double) o).doubleValue(),
            9.989667788E304,
            0.000000001E304);

        try {
            msg.readDouble();
            fail();
        } catch (MessageEOFException ex) {
        }
        msg.reset();
        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }

        checkMessageAttributes();
    }

    public void testString() throws JMSException {

        msg.writeString("123");
        try {
            msg.readString();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.reset();
        assertEquals(msg.readString(), "123");
        msg.reset();
        assertEquals(msg.readByte(), Byte.valueOf("123").byteValue());
        msg.reset();
        Object o = msg.readObject();
        assertTrue(o instanceof String);
        assertEquals(o.toString(), "123");

        try {
            msg.readString();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.clearBody();

        msg.writeObject("124");
        msg.reset();
        o = msg.readObject();
        assertTrue(o instanceof String);
        assertEquals(o.toString(), "124");
        msg.reset();
        assertEquals(msg.readShort(), Short.valueOf("124").shortValue());
        msg.reset();
        assertEquals(msg.readInt(), Integer.valueOf("124").intValue());
        msg.reset();
        assertEquals(msg.readLong(), Long.valueOf("124").longValue());
        msg.reset();
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        msg.clearBody();
        msg.writeString("a");
        msg.reset();
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageFormatException ex) {
        }
        msg.clearBody();
        msg.writeString("123.55");
        msg.reset();
        assertEquals(
            msg.readFloat(),
            Float.valueOf("123.55").floatValue(),
            (float) 0.01);
        msg.reset();
        assertEquals(
            msg.readDouble(),
            Double.valueOf("123.55").doubleValue(),
            0.01);

        msg.clearBody();
        msg.writeString(Boolean.TRUE.toString());
        msg.reset();
        assertTrue(msg.readBoolean());

        msg.clearBody();
        msg.writeString(null);
        msg.reset();
        assertNull(msg.readObject());
        msg.reset();
        assertNull(msg.readString());

        checkMessageAttributes();
    }

    public void testObject() throws JMSException {
        try {
            msg.writeObject(new Object());
            fail();
        } catch (MessageFormatException ex) {
        }
        msg.writeObject(null);
        try {
            msg.readObject();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        msg.writeObject(new Boolean(false));
        msg.writeObject(new Byte((byte) 101));
        msg.writeObject(new byte[] { 11, 22, 33 });
        msg.writeObject(new Character('t'));
        msg.writeObject(new Short((short) 29999));
        msg.writeObject(new Integer(65537));
        msg.writeObject(new Long(888880000011111L));
        msg.writeObject(new Float((float) 7788.001));
        msg.writeObject(new Double(-1.889911001E-301));
        msg.writeObject(new String("String"));

        msg.reset();

        try {
            msg.writeObject(null);
            fail();
        } catch (MessageNotWriteableException ex) {
        }
        assertNull(msg.readObject());
        Object o = msg.readObject();
        assertTrue(o instanceof Boolean);
        assertFalse(((Boolean) o).booleanValue());
        o = msg.readObject();
        assertTrue(o instanceof Byte);
        assertEquals(((Byte) o).byteValue(), (byte) 101);
        o = msg.readObject();
        assertTrue(o instanceof byte[]);
        assertEquals(((byte[]) o).length, 3);
        assertEquals(((byte[]) o)[0], (byte) 11);
        assertEquals(((byte[]) o)[1], (byte) 22);
        assertEquals(((byte[]) o)[2], (byte) 33);
        o = msg.readObject();
        assertTrue(o instanceof Character);
        assertEquals(((Character) o).charValue(), 't');
        o = msg.readObject();
        assertTrue(o instanceof Short);
        assertEquals(((Short) o).shortValue(), (short) 29999);
        o = msg.readObject();
        assertTrue(o instanceof Integer);
        assertEquals(((Integer) o).intValue(), 65537);
        o = msg.readObject();
        assertTrue(o instanceof Long);
        assertEquals(((Long) o).longValue(), 888880000011111L);
        o = msg.readObject();
        assertTrue(o instanceof Float);
        assertEquals(((Float) o).floatValue(), (float) 7788.001, (float) 0.001);
        o = msg.readObject();
        assertTrue(o instanceof Double);
        assertEquals(
            ((Double) o).doubleValue(),
            -1.889911001E-301,
            0.000000001E-301);
        o = msg.readObject();
        assertTrue(o instanceof String);
        assertEquals(o, "String");

        checkMessageAttributes();
    }

    public void testByteArray() throws JMSException {

        byte[] bytes1 = { 1, 0, 1, 0, 11, 127, -128, 11, 15 };

        msg.writeBytes(bytes1);
        msg.writeBytes(bytes1, 2, 5);
        for (int i = 0; i < bytes1.length; bytes1[i++] = 0);

        try {
            msg.readBytes(new byte[1]);
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg.writeBytes(bytes1, -1, 1);
            fail();
        } catch (IllegalArgumentException ex) {
        }
        try {
            msg.writeBytes(bytes1, 1, -1);
            fail();
        } catch (IllegalArgumentException ex) {
        }
        try {
            msg.writeBytes(bytes1, 1, 111);
            fail();
        } catch (IllegalArgumentException ex) {
        }

        msg.writeBytes(null);
        msg.writeBytes(null, 0, 0);
        msg.reset();

        bytes1 = new byte[6];
        assertEquals(msg.readBytes(bytes1), 6);
        assertEquals(bytes1[0], (byte) 1);
        assertEquals(bytes1[1], (byte) 0);
        assertEquals(bytes1[2], (byte) 1);
        assertEquals(bytes1[3], (byte) 0);
        assertEquals(bytes1[4], (byte) 11);
        assertEquals(bytes1[5], (byte) 127);
        assertEquals(msg.readBytes(bytes1), 3);
        assertEquals(bytes1[0], (byte) - 128);
        assertEquals(bytes1[1], (byte) 11);
        assertEquals(bytes1[2], (byte) 15);
        assertEquals(bytes1[3], (byte) 0);
        assertEquals(bytes1[4], (byte) 11);
        assertEquals(bytes1[5], (byte) 127);
        assertEquals(msg.readBytes(bytes1), -1);
        assertEquals(bytes1[0], (byte) - 128);
        assertEquals(bytes1[1], (byte) 11);
        assertEquals(bytes1[2], (byte) 15);
        assertEquals(bytes1[3], (byte) 0);
        assertEquals(bytes1[4], (byte) 11);
        assertEquals(bytes1[5], (byte) 127);

        assertEquals(msg.readBytes(bytes1), 5);
        assertEquals(bytes1[0], (byte) 1);
        assertEquals(bytes1[1], (byte) 0);
        assertEquals(bytes1[2], (byte) 11);
        assertEquals(bytes1[3], (byte) 127);
        assertEquals(bytes1[4], (byte) - 128);
        assertEquals(bytes1[5], (byte) 127);
        assertEquals(msg.readBytes(bytes1), -1);
        assertEquals(bytes1[0], (byte) 1);
        assertEquals(bytes1[1], (byte) 0);
        assertEquals(bytes1[2], (byte) 11);
        assertEquals(bytes1[3], (byte) 127);
        assertEquals(bytes1[4], (byte) - 128);
        assertEquals(bytes1[5], (byte) 127);

        // Read two null values and check that the bytes array is not modified
        assertEquals(msg.readBytes(bytes1), -1);
        assertEquals(bytes1[0], (byte) 1);
        assertEquals(bytes1[1], (byte) 0);
        assertEquals(bytes1[2], (byte) 11);
        assertEquals(bytes1[3], (byte) 127);
        assertEquals(bytes1[4], (byte) - 128);
        assertEquals(bytes1[5], (byte) 127);

        assertEquals(msg.readBytes(bytes1), -1);
        assertEquals(bytes1[0], (byte) 1);
        assertEquals(bytes1[1], (byte) 0);
        assertEquals(bytes1[2], (byte) 11);
        assertEquals(bytes1[3], (byte) 127);
        assertEquals(bytes1[4], (byte) - 128);
        assertEquals(bytes1[5], (byte) 127);

        try {
            msg.readObject();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();

        try {
            msg.readBoolean();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readByte();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readChar();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readShort();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readInt();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readLong();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readFloat();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readDouble();
            fail();
        } catch (MessageFormatException ex) {
        }
        try {
            msg.readString();
            fail();
        } catch (MessageFormatException ex) {
        }
        checkMessageAttributes();
    }

    public void testClone() throws JMSException {

        msg.writeByte((byte) 253);
        msg.writeBytes(new byte[] { 55, 66, 77 });
        msg.writeString("string");

        StreamMessage msg1 = new StreamMessageImpl(msg);

        try {
            msg.readObject();
            fail();
        } catch (MessageNotReadableException ex) {
        }
        try {
            msg1.readObject();
            fail();
        } catch (MessageNotReadableException ex) {
        }

        assertTrue(MessageUtility.compare(msg, msg1));

        msg.writeChar('u');
        msg1.writeChar('x');

        msg.reset();
        assertEquals(msg.readByte(), (byte) 253);
        byte[] bytes = new byte[3];
        assertEquals(msg.readBytes(bytes), 3);
        assertEquals(msg.readBytes(bytes), -1);
        assertEquals(bytes[0], (byte) 55);
        assertEquals(bytes[1], (byte) 66);
        assertEquals(bytes[2], (byte) 77);
        assertEquals(msg.readString(), "string");
        assertEquals(msg.readChar(), 'u');
        try {
            msg.readObject();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg1.reset();
        assertEquals(msg1.readByte(), (byte) 253);
        bytes = new byte[3];
        assertEquals(msg1.readBytes(bytes), 3);
        assertEquals(msg1.readBytes(bytes), -1);
        assertEquals(bytes[0], (byte) 55);
        assertEquals(bytes[1], (byte) 66);
        assertEquals(bytes[2], (byte) 77);
        assertEquals(msg1.readString(), "string");
        assertEquals(msg1.readChar(), 'x');
        try {
            msg1.readObject();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg.reset();
        msg.readObject();
        msg.readObject();
        msg1 = new StreamMessageImpl(msg);

        assertEquals(msg.readString(), "string");
        assertEquals(msg.readChar(), 'u');
        try {
            msg.readObject();
            fail();
        } catch (MessageEOFException ex) {
        }

        msg1.writeChar('f');
        msg1.reset();

        checkMessageAttributes(msg1);

        assertEquals(msg1.readByte(), (byte) 253);
        bytes = new byte[3];
        assertEquals(msg1.readBytes(bytes), 3);
        assertEquals(msg1.readBytes(bytes), -1);
        assertEquals(bytes[0], (byte) 55);
        assertEquals(bytes[1], (byte) 66);
        assertEquals(bytes[2], (byte) 77);
        assertEquals(msg1.readString(), "string");
        assertEquals(msg1.readChar(), 'u');
        assertEquals(msg1.readChar(), 'f');
        try {
            msg1.readObject();
            fail();
        } catch (MessageEOFException ex) {
        }

        checkMessageAttributes(msg1);
        checkMessageAttributes();
    }

}
