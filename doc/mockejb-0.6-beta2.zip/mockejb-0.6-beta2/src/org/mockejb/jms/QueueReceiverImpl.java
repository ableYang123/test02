package org.mockejb.jms;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueReceiver;

/**
 * @author Dimitar Gospodinov
 */
public class QueueReceiverImpl extends MockConsumer implements QueueReceiver {

    /**
     * @param queue
     */
    public QueueReceiverImpl(MockSession sess, MockQueue queue) {
        super(sess, queue);
     }

    /**
     * @see javax.jms.QueueReceiver#getQueue()
     */
    public Queue getQueue() throws JMSException {
        return (Queue)getDestination();
    }

}
