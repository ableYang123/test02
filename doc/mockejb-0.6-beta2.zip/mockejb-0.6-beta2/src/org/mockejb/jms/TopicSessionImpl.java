package org.mockejb.jms;

import javax.jms.*;
import org.mockejb.MethodNotImplementedException;

/**
 * <code>TopicSession</code> implementation.
 * Only topics of type <code>MockTopic</code> are supported.
 * @author Dimitar Gospodinov
 */
class TopicSessionImpl extends MockSession implements TopicSession {

    /**
     * Creates new topic session with the specified attributes.
     * @param transacted
     * @param acknowledgeMode
     */
    TopicSessionImpl(boolean transacted, int acknowledgeMode, MockConnection connection) {
        super(transacted, acknowledgeMode, connection);
    }

    /**
     * Not implemented.
     * @see javax.jms.TopicSession#createTopic(java.lang.String)
     */
    public Topic createTopic(String topicName) throws JMSException {
        throw new MethodNotImplementedException(
            "createTopic",
            "TopicSessionImpl");
    }

    /**
     * Creates subscriber for <code>topic</code>
     * @see javax.jms.TopicSession#createSubscriber(javax.jms.Topic)
     */
    public TopicSubscriber createSubscriber(Topic topic) throws JMSException {
        return (TopicSubscriber)createConsumer(topic);
    }

    /**
     * Not implemented.
     * @see javax.jms.TopicSession#createSubscriber(
     *              javax.jms.Topic, java.lang.String, boolean)
     */
    public TopicSubscriber createSubscriber(
        Topic topic,
        String messageSelector,
        boolean noLocal)
        throws JMSException {

        throw new MethodNotImplementedException(
            "createSubscriber",
            "TopicSessionImpl");
    }

    /**
     * Not implemented.
     * @see javax.jms.TopicSession#createDurableSubscriber(
     *              javax.jms.Topic, java.lang.String)
     */
    public TopicSubscriber createDurableSubscriber(Topic topic, String name)
        throws JMSException {

        throw new MethodNotImplementedException(
            "createDurableSubscriber",
            "TopicSessionImpl");
    }

    /**
     * Not implemented.
     * @see javax.jms.TopicSession#createDurableSubscriber(
     *              javax.jms.Topic, java.lang.String,
     *              java.lang.String, boolean)
     */
    public TopicSubscriber createDurableSubscriber(
        Topic topic,
        String name,
        String messageSelector,
        boolean noLocal)
        throws JMSException {

        throw new MethodNotImplementedException(
            "createDurableSubscriber",
            "TopicSessionImpl");
    }

    /**
     * Creates topic publisher for <code>topic</code>.
     * <code>topic</code> must be <code>MockTopic</code>.
     * @return <code>TopicPublisher</code> for <code>topic</code>
     * @throws InvalidDestinationException if <code>topic</code>
     * is not instance of <code>MockTopic</code>
     * @see javax.jms.TopicSession#createPublisher(javax.jms.Topic)
     */
    public TopicPublisher createPublisher(Topic topic) throws JMSException {
        checkClosed();
        return (TopicPublisher)createProducer(topic);
    }

    public TemporaryTopic createTemporaryTopic() throws JMSException {
        throw new MethodNotImplementedException(
            "createTemporaryTopic",
            "TopicSessionImpl");
    }

    public void unsubscribe(String name) throws JMSException {
        throw new MethodNotImplementedException(
            "unsubscribe",
            "TopicSessionImpl");
    }
    
    /**
     * Throws <code>IllegalStateException</code>
     */
    public Queue createQueue(String queueName) throws JMSException {

        throw new javax.jms.IllegalStateException(
            "Topic session can not create queue!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public QueueBrowser createBrowser(Queue queue) throws JMSException {

        throw new javax.jms.IllegalStateException(
            "Topic session can not create queue browser!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public QueueBrowser createBrowser(Queue queue, String messageSelector)
        throws JMSException {

        throw new javax.jms.IllegalStateException(
            "Topic session can not create queue browser!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public TemporaryQueue createTemporaryQueue() throws JMSException {
        throw new javax.jms.IllegalStateException(
            "Topic session can not create temporary queue!");
    }


    // Non-standard methods

    MockConsumer createMockConsumer(MockDestination destination) throws JMSException {
        if (destination instanceof MockTopic) {
            return new TopicSubscriberImpl(this, (MockTopic) destination);
        }
        throw new InvalidDestinationException("Invalid topic specified!");
    }
    
    MockProducer createMockProducer(MockDestination destination) throws JMSException {
        if (destination instanceof MockTopic) {
            return new TopicPublisherImpl((MockTopic) destination);
        }
        throw new InvalidDestinationException("Invalid topic specified!");        
    }

}
