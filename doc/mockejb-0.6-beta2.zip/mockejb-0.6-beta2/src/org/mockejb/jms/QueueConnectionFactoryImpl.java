package org.mockejb.jms;

import javax.jms.*;

/**
 * <code>QueueConnectionFactory</code> implementation.
 * @author Dimitar Gospodinov
 * @see javax.jms.QueueConnectionFactory
 */
public class QueueConnectionFactoryImpl implements QueueConnectionFactory {
	
	private static int clientIdSequence = 1;
    
	public Connection createConnection() throws JMSException {
		return createQueueConnection();
	}
			 
	public Connection createConnection(String userName, String password) throws JMSException {
		return createQueueConnection(userName, password);
	}

	public QueueConnection createQueueConnection(
					 java.lang.String userName, java.lang.String password)  throws JMSException {
		return createQueueConnection();					 	 
    }
    
	public QueueConnection createQueueConnection()  throws JMSException {
		return new QueueConnectionImpl( clientIdSequence++ );					 	 
	}
}
