package org.mockejb.jms;

import javax.jms.*;

/**
 * <code>TextMessage</code> implementation.
 * @author Dimitar Gospodinov
 */
public class TextMessageImpl extends MessageImpl implements TextMessage {

    private String messageText = null;

    /**
     * Creates new <code>TextMessageImpl</code> initialized
     * with the text from <code>msg</code>
     * @param msg
     * @throws JMSException
     */
    public TextMessageImpl(TextMessage msg) throws JMSException {
        super(msg);
        setText(msg.getText());
    }

    /**
     * Creates empty <code>TextMessage</code>
     */
    public TextMessageImpl() {
        super();
    }

    /**
     * Creates new <code>TextMessageImpl</code> initialized with
     * <code>text</code>
     * @param text
     */
    public TextMessageImpl(String text) throws JMSException {
        setText(text);
    }

    /**
     * @see javax.jms.TextMessage#clearBody()
     */
    public void clearBody() throws JMSException {
        super.clearBody();
        messageText = null;
    }

    /**
     * @see javax.jms.TextMessage#setText(java.lang.String)
     */
    public void setText(String text) throws JMSException {
        checkBodyWriteable();
        messageText = text;
    }

    /**
     * @see javax.jms.TextMessage#getText()
     */
    public String getText() throws JMSException {
        return messageText;
    }

    // Non-standard methods

    /**
      * Sets message body in read-only mode.
      * @throws JMSException
      */
    void resetBody() throws JMSException {
        setBodyReadOnly();
    }

}
