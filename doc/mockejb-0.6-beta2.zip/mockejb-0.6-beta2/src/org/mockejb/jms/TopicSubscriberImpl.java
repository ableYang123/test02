package org.mockejb.jms;

import javax.jms.JMSException;
import javax.jms.Topic;
import javax.jms.TopicSubscriber;

/**
 * @author Dimitar Gospodinov
 */
public class TopicSubscriberImpl
    extends MockConsumer
    implements TopicSubscriber {

    /**
     * Creates topic subscriber for the specified session and topic.
     * @param sess session
     * @param topic topic
     */
    public TopicSubscriberImpl(MockSession sess, MockTopic topic) {
        super(sess, topic);
    }

    /**
     * @see javax.jms.TopicSubscriber#getTopic()
     */
    public Topic getTopic() throws JMSException {
        return (Topic)getDestination();
    }

    /**
     * @see javax.jms.TopicSubscriber#getNoLocal()
     */
    public boolean getNoLocal() throws JMSException {
        return false;
    }

}
