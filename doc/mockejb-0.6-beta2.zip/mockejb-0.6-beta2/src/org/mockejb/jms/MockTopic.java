package org.mockejb.jms;

import javax.jms.*;
import java.util.*;

/**
 * <code>Topic</code> implementation.
 * @author Dimitar Gospodinov
 * @see javax.jms.Topic
 */
public class MockTopic extends MockDestination implements Topic {

    private final Collection listeners = new ArrayList(); 

    /**
     * Creates <code>MockTopic</code> with the specified name
     * <code>name</code>
     * @param name
     */
    public MockTopic(String name) {
        super(name);
    }

    /**
     * Returns topic name.
     * @return topic name
     * @see javax.jms.Topic#getTopicName()
     */
    public String getTopicName() throws JMSException {
        return getName();
    }
    
    public void addMessageListener(MessageListener listener) {
            listeners.add(listener);
        }

    public void dispatch(Message msg) {
        Iterator it = listeners.iterator();
        while (it.hasNext()) {
            MessageListener l = (MessageListener)it.next();
            l.onMessage(msg);
        }
    }

}
