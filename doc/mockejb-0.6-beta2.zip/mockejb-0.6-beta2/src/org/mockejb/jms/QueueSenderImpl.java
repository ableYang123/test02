package org.mockejb.jms;

import javax.jms.*;

/**
 * <code>QueueSender</code> implementation.
 * Supports only queues, which are instances of <code>MockQueue</code>
 * @author Dimitar Gospodinov
 * @see javax.jms.QueueSender
 */
class QueueSenderImpl extends MockProducer implements QueueSender {

    /**
     * Creates queue sender for <code>queue</code>
     * @param queue
     */
    QueueSenderImpl(MockQueue queue) {
        super(queue);
    }

    /**
     * @see javax.jms.QueueSender#getQueue()
     */
    public Queue getQueue() throws JMSException {
        return (Queue) getDestination();
    }

    /**
    * @see javax.jms.QueueSender#send(javax.jms.Queue, javax.jms.Message)
    */
    public void send(Queue queue, Message msg) throws JMSException {
        send(queue, msg, getDeliveryMode(), getPriority(), 0);
    }

    /**
     * @see javax.jms.QueueSender#send(javax.jms.Queue, javax.jms.Message, int, int, long)
     */
    public void send(
        Queue queue,
        Message msg,
        int deliveryMode,
        int priority,
        long timeToLive)
        throws JMSException {

        checkDestination(true);
        if (queue instanceof MockQueue) {
            MockProducer.sendMessage(
                (MockQueue) queue,
                msg,
                deliveryMode,
                priority,
                timeToLive);
        }
        throw new InvalidDestinationException("Invalid queue specified!");
    }

}
