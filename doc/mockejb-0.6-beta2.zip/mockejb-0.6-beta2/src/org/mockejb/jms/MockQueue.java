package org.mockejb.jms;

import javax.jms.*;

/**
 * <code>Queue</code> implementation.
 * @author Dimitar Gospodinov
 * @see javax.jms.Queue
 */
public class MockQueue extends MockDestination implements Queue {
    
    private MessageListener listener = null;
    
    /**
     * Creates <code>MockQueue</code> with the specified name
     * <code>name</code>
     * @param name
     */
    public MockQueue(String name) {
        super(name);
    }    
    
    /**
     * @see javax.jms.Queue#getQueueName()
     */
    public String getQueueName() throws JMSException {
        return getName();
    }
    
    public void addMessageListener(MessageListener listener) {
        this.listener = listener;
    }

    public void dispatch(Message msg) {
        if (listener != null) {
            listener.onMessage(msg);
        }
    }

}
