package org.mockejb.jms;

import javax.jms.*;
import org.mockejb.MethodNotImplementedException;

/**
 * <code>QueueSession</code> implementation.
 * Supports only queues, which are instances of <code>MockQueue</code>.
 * @author Dimitar Gospodinov
 * @see javax.jms.QueueSession
 */
class QueueSessionImpl extends MockSession implements QueueSession {

    /**
     * Creates queue session with the specified attributes, for connection <code>connection</code> 
     * @param transacted
     * @param acknowledgeMode
     * @param connection
     */
    QueueSessionImpl(
        boolean transacted,
        int acknowledgeMode,
        MockConnection connection) {
            
        super(transacted, acknowledgeMode, connection);
    }

    /**
     * Not implemented.
     * @see javax.jms.QueueSession#createQueue(java.lang.String)
     */
    public Queue createQueue(String queueName) throws JMSException {
        throw new MethodNotImplementedException(
            "createQueue",
            "QueueSessionImpl");
    }

    /**
     * Not implemented.
     * @see javax.jms.QueueSession#createReceiver(javax.jms.Queue)
     */
    public QueueReceiver createReceiver(Queue queue) throws JMSException {
        checkClosed();
        return (QueueReceiver)createConsumer(queue);
    }

    /**
     * Not implemented.
     * @see javax.jms.QueueSession#createReceiver(javax.jms.Queue, java.lang.String)
     */
    public QueueReceiver createReceiver(Queue queue, String messageSelector)
        throws JMSException {

        throw new MethodNotImplementedException(
            "createReceiver",
            "QueueSessionImpl");
    }

    /**
     * @see javax.jms.QueueSession#createSender(javax.jms.Queue)
     */
    public QueueSender createSender(Queue queue) throws JMSException {
        checkClosed();
        return (QueueSender)createProducer(queue);
    }

    /**
     * @see javax.jms.QueueSession#createBrowser(javax.jms.Queue)
     */
    public QueueBrowser createBrowser(Queue queue) throws JMSException {

        checkClosed();

        if (queue instanceof MockQueue) {
            return new QueueBrowserImpl((MockQueue) queue);
        }
        throw new javax.jms.InvalidDestinationException(
            "Invalid queue specified!");
    }

    /**
     * Not implemented
     */
    public QueueBrowser createBrowser(Queue queue, String messageSelector)
        throws JMSException {

        throw new MethodNotImplementedException(
            "createBrowser",
            "QueueSession");
    }

    /**
     * Not implemented.
     * @see javax.jms.QueueSession#createTemporaryQueue()
     */
    public TemporaryQueue createTemporaryQueue() throws JMSException {

        throw new MethodNotImplementedException(
            "createTemporaryQueue",
            "QueueSession");
    }

    
    /**
     * Throws <code>IllegalStateException</code>
     */
    public Topic createTopic(String topicName) throws JMSException {
        throw new javax.jms.IllegalStateException(
            "Queue session can not create topic!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public TopicSubscriber createDurableSubscriber(Topic topic, String name)
        throws JMSException {

        throw new javax.jms.IllegalStateException(
            "Queue session can not create subscriber!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public TopicSubscriber createDurableSubscriber(
        Topic topic,
        String name,
        String messageSelector,
        boolean noLocal)
        throws JMSException {

        throw new javax.jms.IllegalStateException(
            "Queue session can not create subscriber!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public TemporaryTopic createTemporaryTopic() throws JMSException {
        throw new javax.jms.IllegalStateException(
            "Queue session can not create temporary topic!");
    }

    /**
     * Throws <code>IllegalStateException</code>
     */
    public void unsubscribe(String name) throws JMSException {
        throw new javax.jms.IllegalStateException(
            "Queue session can not \"unsubscribe\"!");
    }


    // Non-standard methods

    MockConsumer createMockConsumer(MockDestination destination) throws JMSException {
        if (destination instanceof MockQueue) {
            return new QueueReceiverImpl(this, (MockQueue) destination);
        }
        throw new InvalidDestinationException("Invalid queue specified!");
    }
    
    MockProducer createMockProducer(MockDestination destination) throws JMSException {
        if (destination instanceof MockQueue) {
            return new QueueSenderImpl((MockQueue) destination);
        }
        throw new InvalidDestinationException("Invalid queue specified!");        
    }


}
