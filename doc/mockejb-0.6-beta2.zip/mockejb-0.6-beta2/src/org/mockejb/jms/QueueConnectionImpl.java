package org.mockejb.jms;

import javax.jms.*;
import org.mockejb.MethodNotImplementedException;

/**
 * <code>QueueConnection</code> implementation.
 * @author Dimitar Gospodinov
 * @see javax.jms.QueueConnection
 */
class QueueConnectionImpl extends MockConnection implements QueueConnection {

    /**
     * Creates new queue connection for the specified client Id.
     * @param clientId
     */
    QueueConnectionImpl(int clientId) {
        super("QueueClient:" + clientId);
    }

    /**
     * Creates queue session.
     */
    public QueueSession createQueueSession(
        boolean transacted,
        int acknowledgeMode)
        throws JMSException {

        return (QueueSession)createSession(transacted, acknowledgeMode);
    }

    /**
     * Not implemented.
     */
    public ConnectionConsumer createConnectionConsumer(
        Queue queue,
        String messageSelector,
        ServerSessionPool sessionPool,
        int maxMessages)
        throws JMSException {

        checkClosed();

        throw new MethodNotImplementedException(
            "createConnectionConsumer",
            "QueueConnectionImpl");
    }

    // Non-standard methods

    MockSession createMockSession(boolean transacted, int acknowledgeMode) {
        return new QueueSessionImpl(transacted, acknowledgeMode, this);
    }

}
