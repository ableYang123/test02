package org.mockejb.jms;

import java.util.Enumeration;
import javax.jms.*;

/**
 * <code>QueueBrowser</code> implementation.
 * @author Dimitar Gospodinov
 * @see javax.jms.QueueBrowser
 */
class QueueBrowserImpl implements QueueBrowser {

    private MockQueue queue;
    
    /**
     * Creates new queue browser for <code>queue</code>
     * @param queue
     */
    QueueBrowserImpl(MockQueue queue) {
        this.queue = queue;
    }

    /**
     * @see javax.jms.QueueBrowser#getQueue()
     */
    public Queue getQueue() throws JMSException {
        return queue;
    }

    /**
     * Returns null.
     * @see javax.jms.QueueBrowser#getMessageSelector()
     */
    public String getMessageSelector() throws JMSException {
        return null;
    }

    /**
     * @see javax.jms.QueueBrowser#getEnumeration()
     */
    public Enumeration getEnumeration() throws JMSException {
        return new CollectionEnumeration(queue.getMessages().iterator());
    }

    /**
     * Does nothing
     * @see javax.jms.QueueBrowser#close()
     */
    public void close() throws JMSException {
        // Does nothing.
    }

}
