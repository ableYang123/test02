package org.mockejb.jms;

import javax.jms.*;

/**
 * <code>TopicConnectionFactory</code> implementation.
 * @author Dimitar Gospodinov
 */
public class TopicConnectionFactoryImpl implements TopicConnectionFactory {

    private static int clientIdSequence = 1;

    public Connection createConnection() throws JMSException {
        return createTopicConnection();
    }

    public Connection createConnection(String userName, String password)
        throws JMSException {
        return createTopicConnection(userName, password);
    }

    public TopicConnection createTopicConnection(String userName, String password)
    				throws JMSException {
        return createTopicConnection();
    }

    public TopicConnection createTopicConnection() throws JMSException {
        return new TopicConnectionImpl( clientIdSequence++ );
    }
}
