package org.mockejb.test;

import javax.ejb.*;

import org.apache.commons.logging.*;

/**
 * Sample stateful session bean.
 * 
 * @ejb:bean type="Stateful" view-type="remote" name="SampleStatefulService" 
 * 	jndi-name="mockejb/SampleStatefulService"
 * @weblogic.clustering home-is-clusterable="False" 
 * 
 */
public class SampleStatefulServiceBean extends BaseSessionBean {
    
    // logger for this class
    private static Log logger = LogFactory.getLog( SampleStatefulServiceBean.class.getName() );
    
    private String someState;
    
    
   /**
    * Returns a variable that was set by the create method
    * 
    * @ejb.interface-method
    * @ejb:transaction type="Supports" 
    */
    public String getSampleState() {
    	
        return this.someState;
        
    }
    
    public void ejbCreate( String someState) throws CreateException {
        log("ejbCreate called");
        
        this.someState = someState;
    }
    
}








