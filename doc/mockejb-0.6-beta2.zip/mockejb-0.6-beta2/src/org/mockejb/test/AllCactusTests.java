package org.mockejb.test;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * MockEJB Cactus tests
 * 
 * @author Alexander Ananiev
 */
public class AllCactusTests {

    public static Test suite() {
        TestSuite suite = new TestSuite("MockEJB Cactus tests");
        
        suite.addTestSuite( FundamentalsTest.class  );
        suite.addTestSuite( JdbcAndTransactionTest.class );
        suite.addTestSuite( StatefulTest.class );

        return suite;
    }
}
