package org.mockejb.test;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

/**
 * Business interface of a sample stateful bean.
 */
public interface SampleStatefulService extends EJBObject {

    public final static String JNDI_NAME = "mockejb/SampleStatefulService";
    
    String getSampleState( ) throws RemoteException;

}
