package org.mockejb.test;

import javax.ejb.*;
import javax.jms.*;
import javax.naming.InitialContext;


import org.apache.commons.logging.*;


/**
 * Primitive example of a message bean
 * @author Alexander Ananiev
 * @ejb.bean name="SampleMessageBean" destination-type="javax.jms.Topic"
 * @weblogic.message-driven  destination-jndi-name="SampleTopic"  connection-factory-jndi-name="SampleConnectionFactory"
 *
 */
public class SampleMessageBean implements MessageDrivenBean, MessageListener   {

    // logger for this class
    private static Log logger = LogFactory.getLog( SampleMessageBean.class.getName() );


    /**
     * Calls StatelessSamppleBean
     *  
     * @ejb.interface-method
     * @ejb:transaction type="Required" 
     */
    public void onMessage(Message msg) {
        
        try {  

            String messageText = ((TextMessage)msg).getText();

            System.out.println("Got message: "+messageText );

            // Lookup the home
            SampleServiceHome sampleHome = (SampleServiceHome) 
                ( new InitialContext()).lookup( SampleService.JNDI_NAME );
                       
            // create the bean
            SampleService sampleBean = sampleHome.create();
            
            sampleBean.echoString( messageText );
        }
        catch ( Exception exception ){
            throw new EJBException( exception ); 
        }
                
         
    }


    /**
     * Sets the session context.
     *
     * @param ctx  MessageDrivenContext Context for session
     */
    public void setMessageDrivenContext(MessageDrivenContext ctx) {
        log("setMessageDrivenContext called");
    }
    
    
    /**
     * This method is required by the EJB Specification,
     * but is not used by this bean.
     */
    public void ejbCreate() throws CreateException {
        log("ejbCreate called");
    }
    
    /**
     * This method is required by the EJB Specification,
     * but is not used by this bean.
     */
    public void ejbRemove() {
        log("ejbRemove called");
    }
    

    private void log(String message) {
        logger.debug(message);
    }


}
