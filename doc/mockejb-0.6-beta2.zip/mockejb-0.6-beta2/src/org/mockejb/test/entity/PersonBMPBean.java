package org.mockejb.test.entity;

import java.util.*;

import javax.ejb.*;

/**
 * Bare-bones example of a BMP entity bean. 
 * Some methods defined on the Person interface are not implemented.
 * ejbLoad and ejbStore are not implemented either, since they 
 * are not relevant for MockEJB testing - MockEJB does not 
 * call them directly. 
 * 
 * @author Alexander Ananiev
 */
public class PersonBMPBean implements EntityBean {

    private EntityContext context = null;

    private long id;
    
    private String firstName;
    private String lastName;
    
    // id sequence simulation
    private static long idSequence=0;
    
    public synchronized static long generateId(){
    	return idSequence++;
    }
    
    // ** Create methods
    
    public long ejbCreate( String firstName, String lastName ){
        setFirstName( firstName );
        setLastName( lastName );
       
        // generate fake id
        id=generateId();
        return id;
    }
    
    public void ejbPostCreate( String firstName, String lastName ){
    }
    

	/**
	 * @return firstName.
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName The firstName to set.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return lastName.
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName The lastName to set.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
    
    // Fake finders implementation
    
    /**
     * This finder always returns the same PK value (1).
     */
    public long ejbFindByName( String firstName, String lastName ){

        return 1;
    }
    
    /**
     * This finder always returns the collection with only one PK value (1).
     */
    public Collection ejbFindByFirstName( String firstName ) {
    	Collection pks = new ArrayList();
        pks.add( new Long(1));
        return pks;
    }

    // Lifecycle Methods
    public void setEntityContext(EntityContext c) {
        context = c;
    }
    public void unsetEntityContext() {
        context = null;
    }
    public void ejbRemove() throws RemoveException { }
    public void ejbActivate() { }
    public void ejbPassivate() { }

    /**
     * MockEJB never calls this method. 
     * @see javax.ejb.EntityBean#ejbStore()
     */
    public void ejbStore() { }
    
    /**
     * MockEJB calls this method after every finder.
     * This is fake implementation that simply sets the PK.
     * The real entity loads itself from the database
     *  
     * @see javax.ejb.EntityBean#ejbLoad()
     */
    public void ejbLoad() { 
        
        System.out.println("Inside ejbLoad");
        id = ((Long) context.getPrimaryKey()).longValue();

    }
    
	/**
	 * @return id.
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(long id) {
		this.id = id;
	}
}