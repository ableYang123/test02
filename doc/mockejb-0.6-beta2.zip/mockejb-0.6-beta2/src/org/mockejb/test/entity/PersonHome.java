package org.mockejb.test.entity;

import java.util.Collection;
import javax.ejb.*;

public interface PersonHome extends EJBLocalHome {

    // ** Create methods
    
    Person create( String firstName, String lastName ) throws CreateException;

    Person create() throws CreateException;

    // ** finders
    Person findByPrimaryKey( long id ) throws FinderException;
    
    Person findByName( String firstName, String lastName) throws FinderException;

    Collection findByFirstName( String firstName ) throws FinderException;

    // home methods
    void updateNames() throws FinderException;;
}