
package org.mockejb.test.entity;

import javax.ejb.*;


public abstract class AddressBean implements EntityBean {

    private EntityContext context = null;

    // getters and setters for CMP fields
    
    /**
     * Returns the PK of this bean. 
     * @return the unique id of the Address bean 
     */
    public abstract long getId();
    
    /**
     * Sets the id of this bean. Container generates and sets it for us, 
     * so this method is not exposed on the business interface.
     */
    public abstract void setId( long id );
    
    
    public abstract String getStreet();
    public abstract void setStreet(String street);

    public abstract String getCity();
    public abstract void setCity(String city);

    public abstract String getState();
    public abstract void setState(String state);

    public abstract String getZipCode();
    public abstract void setZipCode(String zipCode);

    public abstract String getCountry();
    public abstract void setCountry(String country);
    
    // CMR
    public abstract Person getPerson();
    public abstract void setPerson( Person person);

    
    // EJB create method
    public Object ejbCreate(String street, String city,
        String state, String zipCode, String country, Person person) throws CreateException {
        
        setStreet(street);
        setCity(city);
        setState(state);
        setZipCode(zipCode);
        setCountry(country);
        
        return null;
    }
    
    // Set CMR relationships here
    public void ejbPostCreate( String street, String city,
            String state, String zipCode, String country, Person person ) throws CreateException { 
    	
        setPerson( person );
        
    }

    public Object ejbCreate() throws CreateException {
        return null;
    }
    
    public void ejbPostCreate() throws CreateException { }

    // Callback Methods
    
    public void setEntityContext(EntityContext c) {
        context = c;
    }
    public void unsetEntityContext() {
        context = null;
    }
    public void ejbRemove() throws RemoveException { }
    public void ejbActivate() { }
    public void ejbPassivate() { }
    public void ejbStore() { }
    public void ejbLoad() { }
}