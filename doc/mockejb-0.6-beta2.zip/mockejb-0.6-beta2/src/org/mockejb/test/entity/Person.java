package org.mockejb.test.entity;

import java.util.Collection;


public interface Person extends javax.ejb.EJBLocalObject {

    public final static String JNDI_NAME="mockejb/customer";
    
    /**
     * Primary key of the bean
     * @return unique id of the person
     */
    long getId();
    
    String getFirstName();
    void setFirstName(String firstName);

    String getLastName();
    void setLastName(String lastName);
    
    // CMR methods
    Collection getAddresses();
    
    void setAddresses( Collection addresses);

}