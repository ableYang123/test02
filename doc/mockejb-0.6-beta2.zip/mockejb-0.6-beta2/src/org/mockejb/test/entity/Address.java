package org.mockejb.test.entity;


public interface Address extends javax.ejb.EJBLocalObject {
    
    public final static String JNDI_NAME="mockejb/address";
    
    // unique ID of this bean
    public long getId(); 
    
    public String getStreet();
    public void setStreet(String street);

    public String getCity();
    public void setCity(String city);

    public String getState();
    public void setState(String state);

    public String getZipCode();
    public void setZipCode(String zipCode);

    public String getCountry();
    public void setCountry(String country);

    /**
     * Returns the owner of this address. 
     * For this example we assume that address can only belong to one person 
     * @return person
     */
    public Person getPerson();
    
}