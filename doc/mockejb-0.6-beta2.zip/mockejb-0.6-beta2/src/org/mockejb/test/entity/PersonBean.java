package org.mockejb.test.entity;

import java.util.Collection;
import java.util.Iterator;

import javax.ejb.*;


public abstract class PersonBean implements EntityBean {

    private EntityContext context = null;

    
    public Object ejbCreate( String firstName, String lastName ){
        setFirstName( firstName );
        setLastName( lastName );
       
        return null;
    }
    
    public void ejbPostCreate( String firstName, String lastName ){
    }
    
    
    public abstract String getFirstName();
    public abstract void setFirstName(String firstName);
    
    public abstract String getLastName();
    public abstract void setLastName(String lastName);
    
    // CMR
    
    public abstract Collection getAddresses();
    public abstract void setAddresses( Collection addresses);
    
    
    /**
     * Returns the PK of this bean. 
     * @return the unique id of the Person bean 
     */
    public abstract long getId();
    
    /**
     * Sets the id of this bean. Container generates and sets it for us, 
     * so this method is not exposed on the business interface.
     */
    public abstract void setId( long id );
   
    /**
     * Example of the ejbSelect method
     * @return all person beans in the database
     */
    public abstract  Collection ejbSelectAll( ) throws FinderException;

    /**
     * Example of the ejbHome method.
     * It iterates through all persons and changes "Smit" to "Smith".
     * If calls ejbSelectAll to get all records from the database. 
     */
    public void ejbHomeUpdateNames() throws FinderException {
        
        // get all people
        Collection people = ejbSelectAll();
        Iterator i = people.iterator();
        // Change Smit to Smith 
        while(i.hasNext() ){
        	Person person = (Person) i.next();
            if( person.getLastName().equals("Smit")){
            	person.setLastName( "Smith");
            }
        }
        
    }
    

    // Lifecycle Methods
    public void setEntityContext(EntityContext c) {
        context = c;
    }
    public void unsetEntityContext() {
        context = null;
    }
    public void ejbRemove() throws RemoveException { }
    public void ejbActivate() { }
    public void ejbPassivate() { }
    public void ejbStore() { }
    public void ejbLoad() { }
    


}