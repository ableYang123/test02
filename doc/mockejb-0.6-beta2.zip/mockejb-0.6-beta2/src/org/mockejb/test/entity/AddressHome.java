
package org.mockejb.test.entity;

import javax.ejb.CreateException;
import javax.ejb.FinderException;

public interface AddressHome extends javax.ejb.EJBLocalHome {

    /**
     * Creates a new instance of the address for the given person.
     * For this example, we assume that address does not exist w/o a person.
     * @param street
     * @param city
     * @param state
     * @param zipCode
     * @param country
     * @param person
     * @return new instance of an Address bean
     */
    public Address create(String street, String city,
        String state, String zipCode, String country, Person person) throws CreateException;


    public Address findByPrimaryKey(Object key) throws FinderException;
}