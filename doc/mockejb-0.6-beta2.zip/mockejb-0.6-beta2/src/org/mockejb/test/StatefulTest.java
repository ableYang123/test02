package org.mockejb.test;

import javax.naming.*;

import org.mockejb.*;
import org.mockejb.jndi.*;



/**
 * Demonstrates Stateful session bean usage with MockEJB.
 *
 * @author Alexander Ananiev
 */
public class StatefulTest extends OptionalCactusTestCase  {
    
        
    // State of this test case. These variables are initialized by setUp method
    private SampleStatefulServiceHome statefulSampleServiceHome;
         
    public StatefulTest(String name) {
        super(name);
    }
        
    /**
     * Deploy EJBs needed for our tests.
     */    
    public void setUp() throws Exception {
        
        if ( !isRunningOnServer() ) {

            /* Deploy EJBs to the MockContainer if we run outside of the app server
             * In cactus mode all but one EJB are deployed by the app server, so we don't need to
             * do it.
             */    

            MockContextFactory.setAsInitial();
        
            // Create an instance of the MockContainer and pass the JNDI context that 
            // it will use to bind EJBs. 
            MockContainer mockContainer = new MockContainer( new InitialContext() );
        
            /*
             * Create the deployment descriptor of the bean. Stateless and Stateful beans
             * both use SessionBeanDescriptor.
             */        
            SessionBeanDescriptor statefulSampleDescriptor = 
                new SessionBeanDescriptor( SampleStatefulService.JNDI_NAME, 
                SampleStatefulServiceHome.class, SampleStatefulService.class, SampleStatefulServiceBean.class );
            // Mark this bean as stateful. Stateless is the default.
            statefulSampleDescriptor.setStateful( true );
        
            mockContainer.deploy( statefulSampleDescriptor );
        }

        // All EJBs are now deployed

        //Look up the home in JNDI
        Context context = new InitialContext( );
        statefulSampleServiceHome = 
            (SampleStatefulServiceHome)context.lookup( SampleStatefulService.JNDI_NAME );

    }


    
    /**
     * Simple stateful session bean test.
     */
    public void testStatefulSessionBean() throws Exception { 

        String someState = "some state";

        // create the bean
        SampleStatefulService sampleStatefulService = statefulSampleServiceHome.create( someState);
        
        // Call the bean and make sure that it returns the same state
        String returnedState = sampleStatefulService.getSampleState();
        assertEquals( someState, returnedState );
        // remove the bean
        sampleStatefulService.remove();
    }
        
}
