package org.mockejb.test;

import org.mockejb.EntityBeanSubclass;
import org.mockejb.test.entity.AddressBean;

import junit.framework.TestCase;

/**
 * 
 * @author Alexander Ananiev
 */
public class EntityBeanSubclassTest extends TestCase {

    protected void setUp() throws Exception {
        super.setUp();
    }
    
    /**
     * Constructor for EntityBeanSubclassTest.
     * @param testCaseName
     */
    public EntityBeanSubclassTest(String testCaseName) {
        super( testCaseName );
    }
    
    public void testSetGet() throws Exception {
        
        EntityBeanSubclass addressSubclass = EntityBeanSubclass.newInstance( AddressBean.class );
        
        AddressBean addressBean = (AddressBean)addressSubclass.create();
        
        addressBean.setCity("test");
        assertEquals( "test", addressBean.getCity());
        
        //addressBean.setPrimaryKey(1);
        //int pk = addressBean.getPrimaryKey();
        //assertEquals(1, pk);
        
    }
}
