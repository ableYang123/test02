package org.mockejb.test;

import javax.naming.*;

import java.sql.*;
import javax.sql.DataSource;


/**
 * Simple EJB with some auxiliary methods. 
 * 
 * @ejb:bean type="Stateless" view-type="local" name="SampleHelper" local-jndi-name="mockejb/SampleHelper"
 * @ejb:interface local-class="org.mockejb.test.SampleHelper"
 * @ejb:home local-class="org.mockejb.test.SampleHelperHome"
 * @ejb.resource-ref  res-ref-name="jdbc/SampleDataSource"  res-type="javax.sql.DataSource"  res-auth="Container" jndi-name="jdbc/SampleDataSource"
 * 
 */
public class SampleHelperBean extends BaseSessionBean {
    
   	/**
     * Simple method to return a predefined string for testing purposes.
     * @param param this parameter is ignored. It is here only for testing. 
     * @ejb.interface-method
     * @ejb:transaction type="Supports" 
     */
    public String dummyMethod( String param) {
    	
        return getClass().getName();
        
    }
    
    /**
     * Example of a database insert
     * 
     * @ejb.interface-method
     * @ejb:transaction type="Supports" 
     */
    public void insertData() throws NamingException, SQLException {

        Context ctx = new InitialContext();
        
        DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/SampleDataSource");
        
        Connection con = ds.getConnection();
        Statement stmt =con.createStatement();
        stmt.execute("insert into test_table values('ts')" );

        con.close();
        
    }   
    
    /**
     * @ejb.interface-method
     * @ejb:transaction type="Supports" 
     */   
    public void throwSystemException() throws RuntimeException {
        throw new RuntimeException("Example of a system exception");
    } 
    
    
}








