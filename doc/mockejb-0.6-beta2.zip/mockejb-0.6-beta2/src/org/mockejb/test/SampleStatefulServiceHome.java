package org.mockejb.test;

import javax.ejb.CreateException;
import java.rmi.RemoteException;

/**
 * Home interface for SampleStatefulService. 
 */
public interface SampleStatefulServiceHome extends javax.ejb.EJBHome {

   public SampleStatefulService create( String someState ) throws CreateException, RemoteException;
   

}
