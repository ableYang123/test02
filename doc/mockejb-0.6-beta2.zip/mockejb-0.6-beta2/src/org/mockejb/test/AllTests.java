package org.mockejb.test;

import org.mockejb.test.entity.BMPEntityBeanTest;
import org.mockejb.test.entity.EntityBeanTest;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * Suite with all MockEjb tests
 * 
 * @author Alexander Ananiev
 */
public class AllTests {

    public static Test suite() {
        TestSuite suite = new TestSuite("MockEjb tests");
        
        // Tests for other packages
        suite.addTestSuite( org.mockejb.jndi.MockContextTest.class );
        suite.addTestSuite( org.mockejb.test.EntityBeanSubclassTest.class );
        suite.addTest( org.mockejb.interceptor.test.AllTests.suite() );
        
        // "integration" tests
        suite.addTestSuite( HelloWorldTest.class  );
        suite.addTestSuite( FundamentalsTest.class  );
        suite.addTestSuite( MDBTest.class );
        suite.addTestSuite( JdbcAndTransactionTest.class );
        suite.addTestSuite( StatefulTest.class );
        // Entity tests
        suite.addTestSuite( EntityBeanTest.class );
        suite.addTestSuite( BMPEntityBeanTest.class );

        return suite;
    }
}
