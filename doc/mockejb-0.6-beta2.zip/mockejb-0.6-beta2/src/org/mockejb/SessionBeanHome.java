package org.mockejb;

import java.lang.reflect.*;

import javax.ejb.*;

/**
 * TODO: update
 * 
 * @author Alexander Ananiev
 */
class SessionBeanHome extends BasicEjbHome {

    
    
    SessionBeanHome( BasicEjbDescriptor descriptor ){
    	super( descriptor );
    }


    /**
     * Creates Session bean. It involves instantiating it, setting the context and 
     * calling "create".
     * Note that if the instantiated bean was already passed in the descriptor,
     * setContext and create are called only if the bean implements SessionBean interface.
     *  
     * @see org.mockejb.BasicEjbHome#create(org.mockejb.BasicEjbDescriptor, org.mockejb.MockEjbObject, java.lang.reflect.Method, java.lang.Object[])
     */
    public Object create( BasicEjbDescriptor descriptor, MockEjbObject ejbObject, 
            Method createMethod, Object[] paramVals ) throws Exception  {
        
        Object bean = createBean( descriptor );
        
        MockEjbContext ejbContext = new MockEjbContext( getHomeProxy() );
        
        if ( bean instanceof SessionBean ) {

            Class paramTypes[]={ SessionContext.class };
            Object args[]={ ejbContext };
            
            invokeBeanMethod(bean, null, 
                    "setSessionContext", paramTypes, args );
            
            invokeBeanCreateMethod( bean, createMethod, paramVals ); 
        }

        Object ejbObjectProxy = ejbObject.createProxy( bean, ejbContext );
        
        return ejbObjectProxy;        
    }

    public Object invokeHomeMethod( BasicEjbDescriptor descriptor,  
            Method homeMethod, Object[] paramVals ) throws Exception{
        
        throwMethodNotImplemented( homeMethod.toString() );
        
        return null;

    }
    

}
