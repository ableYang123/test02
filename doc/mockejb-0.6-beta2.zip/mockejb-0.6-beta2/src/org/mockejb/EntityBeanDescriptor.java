package org.mockejb;

import java.lang.reflect.Modifier;

/**
 * Contains entity bean-specific data used for EJB deployment.
 * Currently only has <code>isCMP</code> flag.
 * 
 * @author Alexander Ananiev
 */
public class EntityBeanDescriptor extends BasicEjbDescriptor {
    
    /**
     * Creates a new instance of the descriptor.
     * @param jndiName  jndiName to bind Home to
     * @param homeClass class of the home interface 
     * @param ifaceClass class of the business interface, remote or local
     * @param beanClass class of the implementation class, can be the abstract class
     * in case of CMP
     */     
    public EntityBeanDescriptor( String jndiName, Class homeClass, Class ifaceClass, 
        Class beanClass ) {

        super( jndiName, homeClass, ifaceClass, beanClass );
    }
    
    /**
     * Returns true if this descriptor is for CMP entity bean, 
     * i.e., abstract bean class was passed to the constructor
     * @return true if CMP, false if BMP
     */
    public boolean isCMP(){
        return Modifier.isAbstract( getBeanClass().getModifiers() ); 
    	
    }
    
}
