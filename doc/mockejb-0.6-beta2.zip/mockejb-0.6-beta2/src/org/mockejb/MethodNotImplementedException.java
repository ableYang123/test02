package org.mockejb;

/**
 * Indicates that the method defined by one of the standard interfaces is 
 * not implemented by the framework. 
 * MockEJB currently does not implement a number of 
 * <code>Context</code> and <code>EJBObject</code> methods. 
 */
public class MethodNotImplementedException extends RuntimeException {
        
    public MethodNotImplementedException( String methodName, String className  ) {
        super( "Method "+methodName+" not implemented by the class "+className);
    }

}
