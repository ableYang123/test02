package org.mockejb;

import java.lang.reflect.Method;

/**
 * Indicates that the method you're trying to call must be intercepted, 
 * MockEJB itself does not support this method. 
 * This is usually the case for CMP finders.
 */
public class MustBeInterceptedException extends RuntimeException {

    /**
	 * @param method Method that must have been intercepted
	 */
	public MustBeInterceptedException(Method method) {
		super("The method "+method.getName()+" must be intercepted using AspectSystem and "+ 
                "interceptors. MockEJB does not support CMP finders and sjbSelect methods.\n"+method);
	}
    
    public MustBeInterceptedException() {
        super("The method that you are trying to call must be intercepted using AspectSystem and "+ 
                "interceptors. MockEJB does not support CMP finders and other methods." );
   	
    }
}
