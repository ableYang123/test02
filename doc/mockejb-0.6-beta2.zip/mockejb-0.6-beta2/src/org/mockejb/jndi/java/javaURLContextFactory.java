package org.mockejb.jndi.java;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.InitialContextFactory;
import javax.naming.spi.ObjectFactory;

import org.mockejb.jndi.MockContextFactory;


/**
 * Handles the <code>java:</code> context. The class follows naming convention
 * described in <code>javax.naming.spi.NamingManager.getURLContext()</code>.
 * it delgates to the <code>MockContextFactory</code> to create the context.
 * 
 * @author Alexander Ananiev
 */
public class javaURLContextFactory implements ObjectFactory {

    private InitialContextFactory contextFactory = new MockContextFactory();
    
    public Object getObjectInstance(Object urlInfo, Name name, Context nameCtx, 
        Hashtable env) throws Exception {

        if(urlInfo == null) {
            return contextFactory.getInitialContext( env );
         }
         if(urlInfo instanceof String)
             throw new RuntimeException(
                "Internal error in javaURLContextFactory.getObjectInstance: urlInfo=" + urlInfo);
         if(urlInfo instanceof String[])
             throw new RuntimeException(
                "Internal error in javaURLContextFactory.getObjectInstance: urlInfo=" + urlInfo);
         else
             throw new IllegalArgumentException(
                "javaURLContextFactory.getObjectInstance: argument must be an java URL String or array of URLs");
     }
    

}
