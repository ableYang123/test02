package org.mockejb.jndi;

import javax.naming.*;
import java.util.Properties;

/**
 * MockContext name parser.
 * @author Dimitar Gospodinov
 */
class MockContextNameParser implements NameParser {

    private static final Properties syntax = new Properties();
    static {
        syntax.put("jndi.syntax.direction", "left_to_right");
        syntax.put("jndi.syntax.separator", "/");
        syntax.put("jndi.syntax.ignorecase", "false");
        syntax.put("jndi.syntax.trimblanks", "yes");
    }
    

    /**
     * Parses <code>name</code> into <code>CompoundName</code> using the following
     * <code>CompoundName</code> properties:
     * <p>
     * jndi.syntax.direction = "left_to_right"
     * jndi.syntax.separator = "/"
     * jndi.syntax.ignorecase = "false"
     * jndi.syntax.trimblanks = "yes"
     * <p>
     * Any characters '.' in the name <code>name</code> will be replaced with the
     * separator character specified above, before parsing.
     * @param name name to parse
     * @throws NamingException if naming error occurrs
     */
    public Name parse(String name) throws NamingException {
        return new CompoundName(name.replace('.','/'), syntax);
    }
}
