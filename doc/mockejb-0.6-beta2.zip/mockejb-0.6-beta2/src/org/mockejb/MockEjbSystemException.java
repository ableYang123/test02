package org.mockejb;

import java.io.PrintWriter;
import java.io.StringWriter;


/**
 * Indicates system error in MockEJB framework. This is not
 * the same with EJB system exception which can be any 
 * RuntimeException. MockEjbSystemException signifies the 
 * failure in one of the MockEJB classes.
 *   
 * Support exception chaining for 1.3 users just in case.
 * 
 * @author  Alexander Ananiev
 */
public class MockEjbSystemException extends RuntimeException {
    
    private Throwable cause;
    
    /** 
     * Creates a new instance of <code>MockEjbSystemException</code>.
     * Appends the error stack of the cause to the message to remain 1.3 compliant.
     * @param message error message
     * @param cause cause of the exception
     */
    public MockEjbSystemException( String message, Throwable cause ) {
        super( message +"\nCause:\n" + stackToString( cause ));
        this.cause = cause;
    }

    public MockEjbSystemException( String message ){
        super( message );
    }
    
    public MockEjbSystemException( Throwable cause ){
        this( "", cause );
    }

    /**
     * Returns the cause of this throwable or null if the cause is nonexistent 
     * or unknown. 
     * 
     * @return the cause of this throwable or null if the cause is 
     * nonexistent or unknown
     * 
     */ 
    public Throwable getCause() {
        return cause;
    }

    private static String stackToString( Throwable e ) {
        StringWriter stringWriter = new StringWriter(); 
        e.printStackTrace( new PrintWriter( stringWriter ) );
        
        return stringWriter.toString();
    }

    
}
