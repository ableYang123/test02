package org.mockejb;

import java.security.Principal;
import java.util.*;

/**
 * Provides simple implementation of java.security.Principal.
 * Also stores the roles for the principal.
 * The only purpose of this class is to support two security-related 
 * methods on EJBContext, so the implementation is very simple.
 *
 * @author Alexander Ananiev
 */
public class MockUser implements Principal {
    
    public final static MockUser ANONYMOUS_USER = new MockUser("anonymous");
    
    private String name;
    private List roles = new ArrayList();
    
    public MockUser( final String name ){
        this.name = name;
    }
    
    public MockUser( final String name, String role ){
        this.name = name;
        setRole( role );
    }
    
    public MockUser( final String name, String[] roles ){
        this.name = name;
        setRoles( roles );
    }
    
    /**
     * Sets the roles that this user has
     * @param roles role names
     */
    public void setRoles( String[] roles ){
        this.roles = Arrays.asList( roles );
    }
    
    /**
     * Sets the role that this user has meaning that
     * this user only has one role
     * 
     * @param role name of the role
     */
    public void setRole( String role ){
        roles = new ArrayList();
        roles.add(role);
    }
    
    /**
     * Checks if the given role belongs to this user
     * 
     * @param role role to check
     * @return true if this user has the given role
     */
    public boolean hasRole( String role ){
        return roles.contains( role );
    }

    /**
     * @see java.security.Principal#getName()
     */
    public String getName() {
        return this.name;
    }
    
    public String toString(){
        return name;
    }
    
    
}
