package org.mockejb;


/**
 * Proivides access to the bean (instance of the EJB implementation class) and
 * its context. 
 * Any remote/local interface in MockEJB can be cast to this type to gain 
 * access to the bean. 
 * 
 * @author Alexander Ananiev
 */
public interface EjbBeanAccess {
    
    Object getBean();
    
    /**
     * Returns MockEjbContext of the bean. 
     * MockEjbContext implements all context interfaces.
     * @return instance of MockEjbContext
     */
    MockEjbContext getEjbContext();
    
}
