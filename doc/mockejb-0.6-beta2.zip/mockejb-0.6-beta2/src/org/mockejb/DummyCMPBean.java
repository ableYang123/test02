package org.mockejb;

import java.lang.reflect.Method;

/**
 * Dummmy object used to trigger "must be intercepted" exception when
 * an attempt was made to call finder or ejbSelect that MockEJB does not handle. 
 */
class DummyCMPBean{
	
    public void throwMustBeIntercepted( ) {
		throw new MustBeInterceptedException( );
    }
    
    Method getTargetMethod() throws SecurityException, NoSuchMethodException{
    	
        Method targetMethod = this.getClass().getMethod("throwMustBeIntercepted", 
                new Class[]{});
        
        return targetMethod;
    }
    
}