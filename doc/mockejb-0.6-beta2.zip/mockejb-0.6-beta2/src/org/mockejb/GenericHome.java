package org.mockejb;

/**
 * You can cast any home to this interface and call its create method.
 * Create method will create a new bean's instance and set the context.
 * For session beans, it will call the 
 * parameterless ejbCreate if it exists for. It will not call ejbCreate if the 
 * parameterless ejbCreate does not exist.
 * 
 * For entity beans (BMP and CMP), no ejbCreate/ejbPostCreate method will be called.
 * 
 * This can be used, for example, for BMP entity beans to initialize the bean from 
 * the "back door" without inserting a database record (i.e., calling the actual ejbCreate).  
 * 
 * @author Alexander Ananiev
 */
public interface GenericHome {
    
    
    public Object genericCreate();
    
}
