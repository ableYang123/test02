package org.mockejb;

import java.lang.reflect.*;

import javax.ejb.*;

/**
 * TODO: update
 * 
 * @author Alexander Ananiev
 */
class MDBHome extends BasicEjbHome {

    
    
    MDBHome( BasicEjbDescriptor descriptor ){
    	super( descriptor );
    }


    /**
     * Creates MDB. It involves instantiating it, setting the context and 
     * calling "create".
     * Note that if the instantiated bean was already passed in the descriptor,
     * setContext and create are called only if the bean implements MessageDrivenBean interface.
     *  
     * @see org.mockejb.BasicEjbHome#create(org.mockejb.BasicEjbDescriptor, org.mockejb.MockEjbObject, java.lang.reflect.Method, java.lang.Object[])
     */
    public Object create( BasicEjbDescriptor descriptor, MockEjbObject ejbObject, 
            Method createMethod, Object[] paramVals ) throws Exception  {
        
        Object bean = createBean( descriptor );
        
        MockEjbContext ejbContext = new MockEjbContext( getHomeProxy() );
        
        if ( bean instanceof MessageDrivenBean ) {

            Class paramTypes[]={ MessageDrivenContext.class };
            Object args[]={ ejbContext };
            
            invokeBeanMethod(bean, null, 
                    "setMessageDrivenContext", paramTypes, args );
            
            invokeBeanCreateMethod( bean, createMethod, paramVals ); 
        }

        Object ejbObjectProxy = ejbObject.createProxy( bean, ejbContext );
        
        return ejbObjectProxy;        
    }

    public Object invokeHomeMethod( BasicEjbDescriptor descriptor,  
            Method homeMethod, Object[] paramVals ) throws Exception{
        
        throwMethodNotImplemented( homeMethod.toString() );
        
        return null;

    }
    

}
