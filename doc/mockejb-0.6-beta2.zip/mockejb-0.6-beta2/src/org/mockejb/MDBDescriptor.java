package org.mockejb;

import javax.jms.MessageListener;


/**
 * Provides the information that MockEJB needs to "deploy" MDB.
 * This includes JNDI names of the connection factory and destination. 
 * MockEJB uses its mock JMS implementation to create connection factory and 
 * destination and bind them to JNDI. 
 * It then creates MDB and sets it as the message listener to the destination.   
 *  
 * @author Alexander Ananiev
 */
public class MDBDescriptor extends BasicEjbDescriptor {
    
    private String connectionFactoryJndiName;
    private String destinationJndiName;
    private boolean isTopic = false;
    private boolean isAlreadyBound=false;
    
    private final static String MDB_JNDI_NAME ="FakeMDBJNDIName";
    
    /**
     * Creates a new instance of the descriptor.
     * @param connectionFactoryJndiName JNDI name of the connection factory.
     * @param destinationJndiName JNDI name of the desination. Queue is the default, 
     * unless isTopic is set. 
     * @param bean bean object. Must implement MessageListener interface. 
     */     
    // TODO: Do we need a constructor with the class?
    public MDBDescriptor( String connectionFactoryJndiName, String destinationJndiName, 
            Object bean ) {
    	super(MDB_JNDI_NAME, MDBHomeIface.class, MessageListener.class, bean );
        
        this.connectionFactoryJndiName = connectionFactoryJndiName;
        this.destinationJndiName = destinationJndiName;    
   }
    
    
    public void setIsTopic( boolean isTopic ){
        this.isTopic = isTopic;
    }
    
    /**
     * If set to True, MockEJB will assume that the connection factory and 
     * desination already exist and bound in JNDI. Otherwise, MockEJB will try
     * to create them using Mock JMS objects and bind them to JNDI. 
     * The default is "false".
     * 
     * @param isAlreadyBound do not create destination and connection factory if set to true
     */
    public void setIsAlreadyBound( boolean isAlreadyBound ){
        this.isAlreadyBound = isAlreadyBound;
    }
    

    public String getConnectionFactoryJndiName(){
        return connectionFactoryJndiName;
    }
    
    public String getDestinationJndiName(){
        return destinationJndiName;
    }
    

    public boolean isTopic(){
        return isTopic;
    }
    
    public boolean isAlreadyBound(){
        
        return isAlreadyBound;
    }
    
}
